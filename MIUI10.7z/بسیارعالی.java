import os
import re
import subprocess
import requests
import json
import random
from urllib.parse import quote
from rich import print

# ---------- رنگ‌ها ----------
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"

protocols = ["vmess://", "vless://", "trojan://", "ss://"]

# ---------- توابع اصلی ----------
def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None


def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None


def classify_ping(ping):
    if ping is None:
        return "red", f"{RED}✖ BAD{RESET}"
    elif ping < 150:
        return "green", f"{GREEN}✔ GOOD{RESET}"
    elif ping < 300:
        return "yellow", f"{YELLOW}⚠ WARN{RESET}"
    else:
        return "red", f"{RED}✖ BAD{RESET}"


def fetch_sub_link(url):
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        content = r.text
        content = ''.join([c for c in content if ord(c) < 128])
        return content
    except Exception as e:
        print(f"{RED}❌ Failed to fetch: {url}\nError: {e}{RESET}")
        return None


def parse_configs(raw_data):
    lines = raw_data.splitlines()
    configs = [line.strip() for line in lines if line.strip()]
    return configs


def categorize_configs(configs):
    vless, trojan, ss, others = [], [], [], []
    for cfg in configs:
        lower = cfg.lower()
        if "vless://" in lower:
            vless.append(cfg)
        elif "trojan://" in lower:
            trojan.append(cfg)
        elif "ss://" in lower:
            ss.append(cfg)
        else:
            others.append(cfg)
    return vless, trojan, ss, others


# ---------- ذخیره فایل ----------
def save_to_file(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        for d in data:
            f.write(d + "\n")
    print(f"{GREEN}✅ Saved file: {os.path.abspath(filename)}{RESET}")


def save_json(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"{GREEN}✅ Saved JSON: {os.path.abspath(filename)}{RESET}")


# ---------- فرگمنت ----------
def build_fragment_list(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": extract_host(cfg) or "0.0.0.0",
                    "port": 443,
                    "users": [{
                        "id": "user",
                        "encryption": "none",
                        "flow": ""
                    }]
                }]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {
                    "serverName": extract_host(cfg) or "0.0.0.0",
                    "fingerprint": "chrome",
                    "alpn": ["http/1.1"]
                },
                "wsSettings": {
                    "path": "/",
                    "headers": {
                        "Host": extract_host(cfg) or "0.0.0.0"
                    }
                }
            }
        }
        fragment = {
            "remarks": f"Config {i+1}",
            "log": {"loglevel": "warning"},
            "dns": {},
            "inbounds": [],
            "outbounds": [outbound],
            "routing": {}
        }
        fragments.append(fragment)
    return fragments


def fragment_configs(configs):
    return build_fragment_list(configs)


# ---------- خروجی 3-combo و 2-combo ----------
last_3combo_file = None
internal_2combo = []


def generate_3combo(all_links, count=50):
    combos = []
    max_count = min(count, len(all_links))
    for _ in range(max_count):
        a, b, c = random.sample(all_links, 3)
        combos.append(f"{a}+{b}+{c}")
    return combos


def generate_2combo_from_3combo_file(file_path):
    combos2 = []
    try:
        with open(file_path, "r") as f:
            for line in f:
                parts = line.strip().split('+')
                if len(parts) >= 2:
                    combos2.append(parts[0] + "+" + parts[1])
    except:
        pass
    return combos2


def save_combo_to_file(combo_list, filename, folder):
    path = os.path.join(folder, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(combo_list))
    print(f"{GREEN}✅ Saved {len(combo_list)} combos to: {os.path.abspath(path)}{RESET}")


# ---------- اجرای اصلی ----------
def main():
    global last_3combo_file, internal_2combo
    all_configs = []

    # ---------- جمع‌آوری ورودی ----------
    print("[cyan]Choose input method:[/cyan]")
    print("1) Manual input (Ctrl+D to finish)")
    print("2) Fetch from subscription URL")
    choice = input("Enter choice (1 or 2): ").strip()

    if choice == "1":
        print("[cyan]Paste your configs line by line. Press Ctrl+D to finish:[/cyan]")
        try:
            while True:
                line = input()
                if line.strip():
                    all_configs.append(line.strip())
        except EOFError:
            pass
    elif choice == "2":
        while True:
            url = input("Enter subscription URL: ").strip()
            data = fetch_sub_link(url)
            if data:
                new_cfgs = parse_configs(data)
                all_configs.extend(new_cfgs)
                print(f"{GREEN}✅ Fetched {len(new_cfgs)} configs{RESET}")
            else:
                print("No configs fetched.")
            more = input("Add another link? (y/n): ").strip().lower()
            if more != "y":
                break
    else:
        print("Invalid choice.")
        return

    all_configs = list(set(all_configs))
    vless, trojan, ss, others = categorize_configs(all_configs)

    print(f"\nTotal configs: {len(all_configs)}")
    print(f"VLESS: {len(vless)}")
    print(f"TROJAN: {len(trojan)}")
    print(f"SHADOWSOCKS: {len(ss)}")
    print(f"Others: {len(others)}")

    green, yellow, red = [], [], []
    ping_results = {}

    print("\nPerforming ping checks...")
    for config in all_configs:
        host = extract_host(config)
        if not host:
            print(f"{RED}[INVALID] {config}{RESET}")
            continue
        ping_val = ping_host(host)
        status, label = classify_ping(ping_val)
        print(f"{label} {host} - {ping_val if ping_val else 'NO REPLY'}ms")
        if status == "green":
            green.append(config)
        elif status == "yellow":
            yellow.append(config)
        else:
            red.append(config)
        ping_results[config] = (status, ping_val)

    folder = "/storage/emulated/0/Download/Akbar98"
    os.makedirs(folder, exist_ok=True)

    while True:
        print("\nChoose output:")
        print("1) VLESS only")
        print("2) TROJAN only")
        print("3) SHADOWSOCKS only")
        print("4) All configs")
        print("5) Green ping only")
        print("6) Green + Yellow ping")
        print("7) Fragmented Configs (V2Ray)")
        print("8) Save all as JSON")
        print("9) Generate 3-combo (new)")
        print("10) Generate 2-combo from last 3-combo (new)")
        print("11) Save 2-combo to file (new)")
        print("0) Exit")
        option = input("Enter option number: ").strip()

        if option == "0":
            print("Exiting...")
            break
        elif option == "1":
            fname = input("Enter filename for VLESS (txt): ").strip() or "output_vless.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), vless)
        elif option == "2":
            fname = input("Enter filename for TROJAN (txt): ").strip() or "output_trojan.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), trojan)
        elif option == "3":
            fname = input("Enter filename for SHADOWSOCKS (txt): ").strip() or "output_ss.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), ss)
        elif option == "4":
            fname = input("Enter filename for ALL configs (txt): ").strip() or "output_all.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), all_configs)
        elif option == "5":
            fname = input("Enter filename for GREEN ping (txt): ").strip() or "output_green.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), green)
        elif option == "6":
            fname = input("Enter filename for GREEN+YELLOW ping (txt): ").strip() or "output_green_yellow.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_to_file(os.path.join(folder, fname), green + yellow)
        elif option == "7":
            fname = input("Enter YAML/fragment filename (json): ").strip() or "fragmented_configs.json"
            if not fname.endswith(".json"):
                fname += ".json"
            fragments = fragment_configs(all_configs)
            save_json(os.path.join(folder, fname), fragments)
        elif option == "8":
            fname = input("Enter JSON filename: ").strip() or "output_all.json"
            if not fname.endswith(".json"):
                fname += ".json"
            save_json(os.path.join(folder, fname), all_configs)
        elif option == "9":  # 3-combo
            combos3 = generate_3combo(all_configs)
            fname = input("Enter filename for 3-combo (txt): ").strip() or "combo_3.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            last_3combo_file = os.path.join(folder, fname)
            save_to_file(last_3combo_file, combos3)
        elif option == "10":  # 2-combo from last 3-combo
            if not last_3combo_file:
                print(f"{RED}No previous 3-combo file found.{RESET}")
                continue
            internal_2combo = generate_2combo_from_3combo_file(last_3combo_file)
            print(f"{GREEN}{len(internal_2combo)} 2-combo generated from last 3-combo.{RESET}")
        elif option == "11":  # Save 2-combo
            if not internal_2combo:
                print(f"{RED}No 2-combo to save.{RESET}")
                continue
            fname = input("Enter filename for 2-combo (txt): ").strip() or "combo_2.txt"
            if not fname.endswith(".txt"):
                fname += ".txt"
            save_combo_to_file(internal_2combo, fname, folder)
        else:
            print(f"{RED}Invalid option.{RESET}")


if __name__ == "__main__":
    main()