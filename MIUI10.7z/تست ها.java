#!/data/data/com.termux/files/usr/bin/bash

# مسیر ذخیره خروجی
OUTPUT_DIR="/sdcard/Download/almasi98"
mkdir -p "$OUTPUT_DIR"

# رنگ‌ها
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# منوی اصلی
main_menu() {
    echo -e "${YELLOW}========== Network Test Menu ==========${NC}"
    echo -e "1) ICMP Test"
    echo -e "2) TCP Test"
    echo -e "3) URL Test"
    echo -e "4) Run All Tests"
    echo -e "0) Exit"
    echo -n "Choose an option: "
    read option

    case $option in
        1) protocol="ICMP" ;;
        2) protocol="TCP" ;;
        3) protocol="URL" ;;
        4) protocol="ALL" ;;
        0) exit 0 ;;
        *) echo -e "${RED}Invalid option${NC}"; main_menu ;;
    esac
}

# گرفتن لیست کانفیگ‌ها / URL‌ها
get_targets() {
    echo -e "${YELLOW}Enter each target (SS/VMess URL) per line. Press Ctrl+D when done:${NC}"
    targets=()
    while read line; do
        [ -n "$line" ] && targets+=("$line")
    done
}

# گرفتن نام فایل خروجی
get_output_file() {
    echo -n "Enter output file name (without extension): "
    read filename
    output_path="$OUTPUT_DIR/${filename}.txt"
    # پاک کردن فایل قبلی
    > "$output_path"
}

# تعداد پکت ICMP
get_icmp_count() {
    echo -n "Enter number of ping packets (default 5): "
    read count
    [ -z "$count" ] && count=5
    icmp_count=$count
}

# پورت TCP
get_tcp_port() {
    echo -n "Enter TCP port (default 443): "
    read port
    [ -z "$port" ] && port=443
    tcp_port=$port
}

# تابع تست ICMP
test_icmp() {
    get_icmp_count
    echo -e "${YELLOW}Running ICMP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        ping -c $icmp_count -W 5 $host &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}ICMP Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}ICMP Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

# تابع تست TCP
test_tcp() {
    get_tcp_port
    echo -e "${YELLOW}Running TCP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        nc -z -w 5 $host $tcp_port &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}TCP Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}TCP Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

# تابع تست URL
test_url() {
    echo -e "${YELLOW}Running URL/HTTP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        curl -o /dev/null -s -w "%{http_code}" "https://$host" | grep -q "200\|204"
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}URL Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}URL Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

# حلقه اصلی
while true; do
    main_menu
    get_targets
    get_output_file

    case $protocol in
        ICMP) test_icmp ;;
        TCP) test_tcp ;;
        URL) test_url ;;
        ALL)
            # ذخیره موقت برای هر مرحله
            temp_targets=("${targets[@]}")
            test_icmp
            test_tcp
            test_url
            targets=("${targets[@]}")  # فقط کسانی که هر سه تست را پاس کردند
            ;;
    esac

    # ذخیره فقط کانفیگ‌های سالم
    for target in "${targets[@]}"; do
        echo "$target" >> "$output_path"
    done

    echo -e "${YELLOW}Test completed. Only the best configurations saved to $output_path${NC}"
    echo -e "Press Enter to return to the main menu for another test..."
    read
done