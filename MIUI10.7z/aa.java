import os
import re
import subprocess
import base64
import json
from urllib.parse import quote
from rich import print
from rich.table import Table

# ------------------ Settings ------------------
SAVE_DIR = "/sdcard/Download/almasi98/"
os.makedirs(SAVE_DIR, exist_ok=True)

PROTOCOLS = ("vless://", "vmess://", "trojan://", "ss://", "ssss://")
MAX_COMBOS_PER_BATCH = 50

# ------------------ Input + Ping + Stats ------------------
def extract_host(config: str):
    m = re.search(r"@([^:/?#\s]+)", config)
    if m:
        return m.group(1)
    m = re.search(r"://([^:/?#\s]+)", config)
    return m.group(1) if m else None

def ping_host(host: str):
    try:
        out = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        m = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", out)
        return float(m.group(1)) if m else None
    except Exception:
        return None

def classify_ping(avg_ms: float | None):
    if avg_ms is None:
        return "bad", "[bold red][BAD][/bold red]"
    if avg_ms < 150:
        return "good", "[bold green][GOOD][/bold green]"
    if avg_ms < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    return "bad", "[bold red][BAD][/bold red]"

def get_input():
    print("[cyan]Choose input method:[/cyan]")
    print("1) Manual paste configs (Ctrl+D to finish)")
    print("2) Paste a subscription (base64 text)")
    choice = input("Enter choice [1/2]: ").strip()
    lines = []

    if choice == "1":
        print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
        try:
            while True:
                line = input()
                if line.strip():
                    lines.append(line.strip())
        except EOFError:
            pass
    elif choice == "2":
        b64 = input("Paste base64 subscription text: ").strip()
        try:
            decoded = base64.b64decode(b64).decode(errors="ignore")
            lines = [ln.strip() for ln in decoded.splitlines() if ln.strip()]
        except Exception as e:
            print(f"[red]Failed to decode subscription: {e}[/red]")
    else:
        print("[red]Invalid choice.[/red]")

    return lines

def module_input_ping():
    raw = get_input()
    total_raw = len(raw)

    all_valid = []
    proto_counts = {"vless": 0, "vmess": 0, "trojan": 0, "ss": 0}

    print("\n[bold cyan]Pinging hosts...[/bold cyan]\n")
    for cfg in raw:
        if not cfg.startswith(PROTOCOLS):
            continue

        host = extract_host(cfg)
        if not host:
            print(f"[bold red][INVALID][/bold red] {cfg}")
            continue

        avg = ping_host(host)
        status, label = classify_ping(avg)
        ms = f"{avg:.0f}ms" if avg is not None else "NO REPLY"
        print(f"{label} {host} - {ms}")

        if status in ["good", "warn"]:
            all_valid.append(cfg)

        if cfg.startswith("vless://"):
            proto_counts["vless"] += 1
        elif cfg.startswith("vmess://"):
            proto_counts["vmess"] += 1
        elif cfg.startswith("trojan://"):
            proto_counts["trojan"] += 1
        elif cfg.startswith("ss://") or cfg.startswith("ssss://"):
            proto_counts["ss"] += 1

    table = Table(title="Configs Summary")
    table.add_column("Category")
    table.add_column("Count")
    table.add_row("All raw lines", str(total_raw))
    table.add_row("All valid links", str(len(all_valid)))
    table.add_row("vless", str(proto_counts["vless"]))
    table.add_row("vmess", str(proto_counts["vmess"]))
    table.add_row("trojan", str(proto_counts["trojan"]))
    table.add_row("ss", str(proto_counts["ss"]))
    print()
    print(table)

    return all_valid

# ------------------ Helpers ------------------
def ask_filename(default_name: str, required_ext: str | None = None):
    name = input(f"Enter filename (default: {default_name}): ").strip()
    if not name:
        name = default_name
    if required_ext and not name.endswith(required_ext):
        name += required_ext
    return os.path.join(SAVE_DIR, name)

def strip_protocol(link: str) -> str:
    if "://" in link:
        return link.split("://", 1)[1]
    return link

# ------------------ Combo Generators ------------------
def generate_combo2_consume(configs: list[str], offset: int = 0) -> list[str]:
    combos2 = []
    remaining = configs[offset:].copy()
    while len(remaining) >= 2 and len(combos2) < MAX_COMBOS_PER_BATCH:
        first = remaining.pop(0)
        second = remaining.pop(0)
        combos2.append(f"{first}+{second}")
    return combos2

def generate_combo3_consume(configs: list[str], offset: int = 0) -> list[str]:
    combos3 = []
    remaining = configs[offset:].copy()
    while len(remaining) >= 3 and len(combos3) < MAX_COMBOS_PER_BATCH:
        first = remaining.pop(0)
        second = remaining.pop(0)
        third = remaining.pop(0)
        tail = strip_protocol(third)
        combos3.append(f"{first}+{second}+ss//{tail}")
    return combos3

# ------------------ Output Builders ------------------
def build_fragment_type1(configs: list[str]) -> list[dict]:
    fragments = []
    for i, cfg in enumerate(configs):
        host = extract_host(cfg)
        fragments.append({
            "remarks": f"{cfg[-20:]} Fragment-{i+1}",
            "log": {"loglevel": "warning"},
            "inbounds": [
                {"tag":"socks","port":10808,"listen":"127.0.0.1","protocol":"socks",
                 "sniffing":{"enabled":True,"destOverride":["http","tls"],"routeOnly":False},
                 "settings":{"auth":"noauth","udp":True,"allowTransparent":False}},
                {"tag":"http","port":10809,"listen":"127.0.0.1","protocol":"http",
                 "sniffing":{"enabled":True,"destOverride":["http","tls"],"routeOnly":False},
                 "settings":{"auth":"noauth","udp":True,"allowTransparent":False}}
            ],
            "outbounds":[
                {"tag":"proxy","protocol":"vless","settings":{"vnext":[{"address":host,"port":443,"users":[{"id":"dummy-id","encryption":"none"}]}]}},
                {"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"6-9","interval":"1-2"}}}
            ]
        })
    return fragments

# ------------------ Outputs Menu ------------------
def outputs_menu(configs: list[str]):
    combo2_offset = 0
    combo3_offset = 0

    while True:
        print("\n[cyan]Choose output type:[/cyan]")
        print("1) Raw TXT")
        print("2) JSON (Meta)")
        print("3) Hiddify Fragment")
        print("4) Combo-2 (50 each time)")
        print("5) Combo-3 (50 each time)")
        print("6) Fragment Type 1 (full network)")
        # گزینه ۷ حذف شد
        print("0) Exit")

        choice = input("Enter choice: ").strip()

        if choice == "0":
            break
        elif choice == "1":
            path = ask_filename("raw.txt", ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(configs))
            print(f"[green]Saved:[/green] {path}")
        elif choice == "2":
            path = ask_filename("meta.json", ".json")
            js = {"proxies": configs}
            with open(path, "w", encoding="utf-8") as f:
                json.dump(js, f, indent=2, ensure_ascii=False)
            print(f"[green]Saved JSON:[/green] {path}")
        elif choice == "3":
            path = ask_filename("hiddify.json", ".json")
            frag = build_fragment_type1(configs)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(frag, f, indent=2, ensure_ascii=False)
            print(f"[green]Saved Fragment JSON:[/green] {path}")
        elif choice == "4":
            combos2 = generate_combo2_consume(configs, combo2_offset)
            if not combos2:
                print("[red]No more combos left for Combo-2.[/red]")
                continue
            combo2_offset += len(combos2)
            path = ask_filename(f"combo2_{combo2_offset}.txt", ".txt")
            with open(path, "w", encoding="utf-8")