#!/bin/bash

# ------------------- COLORS -------------------
CYAN="\e[36m"
GREEN="\e[32m"
YELLOW="\e[33m"
RESET="\e[0m"

# ------------------- PATHS -------------------
BASE_PATH="$HOME"
DOWNLOAD_DIR="/sdcard/Download/Akbar98"
SSH_CONFIG="$HOME/.ssh/config"
KNOWN_HOSTS="$HOME/.ssh/known_hosts"

# ------------------- ACCOUNT SELECTION -------------------
echo -e "${CYAN}Select GitHub account:${RESET}"
echo "1) tepo18"
echo "2) almasi98"
echo "3) ahsan-tepo1383"
echo -ne "${CYAN}Choice: ${RESET}"
read -r ACC_CHOICE

case $ACC_CHOICE in
    1) HOST_ALIAS="github-tepo18"; KEY_FILE="$HOME/.ssh/id_ed25519"; USERNAME="tepo18";;
    2) HOST_ALIAS="github-almasi"; KEY_FILE="$HOME/.ssh/id_ed25519_almasi"; USERNAME="almasi98";;
    3) HOST_ALIAS="github-ahsan"; KEY_FILE="$HOME/.ssh/id_ed25519_ahsan"; USERNAME="ahsan-tepo1383";;
    *) echo -e "${YELLOW}Invalid choice. Exiting.${RESET}"; exit 1;;
esac

# ------------------- CONFIGURE SSH HOST -------------------
mkdir -p "$HOME/.ssh"
touch "$KNOWN_HOSTS"
if ! grep -q "Host $HOST_ALIAS" "$SSH_CONFIG" 2>/dev/null; then
    echo -e "${GREEN}Adding $HOST_ALIAS to SSH config...${RESET}"
    {
        echo ""
        echo "Host $HOST_ALIAS"
        echo "    HostName github.com"
        echo "    User git"
        echo "    IdentityFile $KEY_FILE"
    } >> "$SSH_CONFIG"
    chmod 600 "$SSH_CONFIG"
fi

# ------------------- ADD GITHUB TO KNOWN_HOSTS -------------------
if ! ssh-keygen -F github.com >/dev/null 2>&1; then
    echo -e "${GREEN}Adding GitHub to known_hosts...${RESET}"
    ssh-keyscan github.com >> "$KNOWN_HOSTS" 2>/dev/null
    chmod 600 "$KNOWN_HOSTS"
fi

# ------------------- START SSH AGENT AND ADD KEY -------------------
eval "$(ssh-agent -s)" >/dev/null
ssh-add "$KEY_FILE"

# ------------------- REPO SETUP -------------------
echo -ne "${CYAN}Enter repo name to clone/use: ${RESET}"
read -r REPO_NAME
REPO_PATH="$BASE_PATH/$REPO_NAME"

if [ ! -d "$REPO_PATH" ]; then
    echo -e "${GREEN}Cloning repo via SSH...${RESET}"
    git clone "git@$HOST_ALIAS:$USERNAME/$REPO_NAME.git" "$REPO_PATH" || { echo "Clone failed!"; exit 1; }
else
    echo -e "${GREEN}Repo folder exists. Using existing repo.${RESET}"
fi

cd "$REPO_PATH" || { echo "Cannot enter repo folder."; exit 1; }

# ------------------- MAIN MENU -------------------
while true; do
    echo -e "\n${CYAN}Select an option:${RESET}"
    echo "1) Create new file"
    echo "2) Edit existing file"
    echo "3) Delete a file"
    echo "4) Commit changes"
    echo "5) Push to GitHub (SSH)"
    echo "6) Copy content from download folder to repo file"
    echo "7) Run checker scripts"
    echo "8) Help"
    echo "9) Exit"
    echo -ne "${CYAN}Choice: ${RESET}"
    read -r CHOICE

    case $CHOICE in
        1)
            echo -ne "${CYAN}Enter new filename to create: ${RESET}"
            read -r NEWFILE
            [ -e "$NEWFILE" ] && echo -e "${YELLOW}File already exists.${RESET}" || (touch "$NEWFILE" && echo -e "${GREEN}File '$NEWFILE' created.${RESET}")
            ;;
        2)
            echo -ne "${CYAN}Enter filename to edit: ${RESET}"
            read -r EDITFILE
            [ ! -e "$EDITFILE" ] && echo -e "${YELLOW}File does not exist.${RESET}" || nano "$EDITFILE"
            ;;
        3)
            echo -ne "${CYAN}Enter filename to delete: ${RESET}"
            read -r DELFILE
            [ ! -e "$DELFILE" ] && echo -e "${YELLOW}File does not exist.${RESET}" || (rm -i "$DELFILE" && echo -e "${GREEN}File deleted.${RESET}")
            ;;
        4)
            git status
            echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
            read -r MSG
            git add .
            [ -z "$MSG" ] && MSG="auto update from script"
            git commit -m "$MSG" 2>/dev/null || echo -e "${YELLOW}Nothing to commit.${RESET}"
            ;;
        5)
            echo -ne "${CYAN}Push changes to GitHub via SSH? (yes/no): ${RESET}"
            read -r PUSH_ANSWER
            if [ "$PUSH_ANSWER" == "yes" ]; then
                branch_name=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
                [ "$branch_name" = "HEAD" ] && branch_name="auto-push-branch" && git switch -c "$branch_name"
                git add -A
                echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
                read -r MSG
                [ -z "$MSG" ] && MSG="auto update from script"
                git commit -m "$MSG" --allow-empty
                git push "git@$HOST_ALIAS:$USERNAME/$REPO_NAME.git" --force && echo -e "${GREEN}Pushed successfully.${RESET}" || echo -e "${YELLOW}Push failed.${RESET}"
            else
                echo "Push canceled."
            fi
            ;;
        6)
            echo -ne "${CYAN}Enter source filename inside download folder ($DOWNLOAD_DIR): ${RESET}"
            read -r SRCFILE
            SRC_PATH="$DOWNLOAD_DIR/$SRCFILE"
            [ ! -f "$SRC_PATH" ] && echo -e "${YELLOW}Source file not found.${RESET}" && continue
            echo -ne "${CYAN}Enter target filename inside repo folder: ${RESET}"
            read -r TARGETFILE
            cat "$SRC_PATH" > "$TARGETFILE"
            echo -e "${GREEN}Content from '$SRC_PATH' copied to '$TARGETFILE'.${RESET}"
            ;;
        7)
            echo -e "${CYAN}Select which checker script to run:${RESET}"
            echo "1) cl.py (repo: sab-vip10)"
            echo "2) cl2.py (repo: sab-vip10)"
            echo "3) cl.py (repo: reza-shah1320)"
            echo -ne "${CYAN}Choice: ${RESET}"
            read -r CHEK_CHOICE
            case $CHEK_CHOICE in
                1|2|3)
                    SCRIPT="./cl.py"
                    [ ! -f "$SCRIPT" ] && echo -e "${YELLOW}$SCRIPT not found.${RESET}" && continue
                    echo -e "${GREEN}Running $SCRIPT...${RESET}"
                    python3 "$SCRIPT"
                    ;;
                *)
                    echo -e "${YELLOW}Invalid choice!${RESET}"
                    ;;
            esac
            ;;
        8)
            echo -e "${CYAN}Help - Main Commands:${RESET}"
            echo "1) Create a new file"
            echo "2) Edit an existing file"
            echo "3) Delete a file"
            echo "4) Commit changes"
            echo "5) Push to GitHub via SSH"
            echo "6) Copy file from download folder to repo"
            echo "7) Run checker scripts"
            echo "8) Show this help menu"
            echo "9) Exit script"
            ;;
        9)
            echo "Exiting."
            exit 0
            ;;
        *)
            echo -e "${YELLOW}Invalid choice!${RESET}"
            ;;
    esac
done