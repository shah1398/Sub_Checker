import os
import re                                                                   import subprocess                                                           import base64
import requests                                                             import json                                                                 from rich import print                                                      from rich.table import Table
                                                                            SAVE_PATH = "/sdcard/Download/almasi98/"                                    os.makedirs(SAVE_PATH, exist_ok=True)
                                                                            protocols = ["vless://", "vmess://", "trojan://", "ss://"]                  
# ------------------ Module 1 (Input + Ping + Stats) ------------------     def extract_host(config):                                                       match = re.search(r"@([^:/?#]+)", config)                                   return match.group(1) if match else None
                                                                            def ping_host(host):                                                            try:
        output = subprocess.check_output(                                               ["ping", "-c", "3", "-W", "1", host],                                       stderr=subprocess.DEVNULL                                               ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)        return float(match.group(1)) if match else None                         except:                                                                         return None
                                                                            def classify_ping(ping):
    if ping is None:                                                                return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:                                                                return "good", "[bold green][GOOD][/bold green]"                        elif ping < 300:                                                                return "warn", "[bold yellow][WARN][/bold yellow]"
    else:                                                                           return "bad", "[bold red][BAD][/bold red]"                          
def get_input():                                                                print("[cyan]Choose input method:[/cyan]")
    print("1) Manual paste configs")                                            print("2) Fetch from sublink (URL)")
    choice = input("Enter choice [1/2]: ").strip()                              lines = []
                                                                                if choice == "1":
        print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")                                                                                  while True:                                                                     try:
                line = input().strip()                                                      if line:                                                                        lines.append(line)                                                  except EOFError:                                                                break
    elif choice == "2":                                                             url = input("Enter sublink URL: ").strip()
        try:                                                                            resp = requests.get(url, timeout=10)                                        decoded = base64.b64decode(resp.text.strip()).decode(errors="ignore")
            lines = decoded.splitlines()                                            except Exception as e:
            print(f"[red]Failed to fetch/parse sublink: {e}[/red]")             return lines                                                                                                                                        def module_input_ping():
    lines = get_input()                                                         total_raw = len(lines)
                                                                                good_configs, yellow_configs, all_configs, hosts, pings = [], [], [], [], []                                                                        
    for line in lines:                                                              if not any(line.startswith(p) for p in protocols):                              continue                                                        
        host = extract_host(line)                                                   if not host:                                                                    print(f"[red][INVALID][/red] {line}")                                       continue                                                                                                                                            ping = ping_host(host)                                                      status, label = classify_ping(ping)                                         print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")                                                                                             if status in ["good", "warn"]:                                                  all_configs.append(line)                                                    hosts.append(host)                                                      if ping:
            pings.append(ping)                                                      if status == "good":                                                            good_configs.append(line)
        elif status == "warn":                                                          yellow_configs.append(line)                                     
    # summary table                                                             table = Table(title="Configs Summary")
    table.add_column("Category")                                                table.add_column("Count")                                                   table.add_row("Total raw input", str(total_raw))
    table.add_row("Valid configs", str(len(all_configs)))                       table.add_row("Green ping", str(len(good_configs)))                         table.add_row("Yellow ping", str(len(yellow_configs)))
    table.add_row("Bad ping", str(total_raw - len(good_configs) - len(yellow_configs)))                                                                 
    print(table)                                                                return all_configs                                                      
# ------------------ Module 2 (Output) ------------------                   def save_file(default_name, content):
    name = input(f"Enter filename (default: {default_name}): ").strip()         if not name:                                                                    name = default_name                                                     with open(SAVE_PATH + name, "w", encoding="utf-8") as f:
        f.write(content)                                                        print(f"[green]Saved: {SAVE_PATH}{name}[/green]")
                                                                            # ------------------ Combo Generators (اصلاح شده) ------------------        def generate_combo2_consume(configs, max_per_batch=50):
    combos2 = []                                                                seen = set()                                                                remaining = configs.copy()                                                  while remaining and len(combos2) < max_per_batch:                               first = remaining.pop(0)
        for second in remaining:                                                        combo = f"{first}+{second}"                                                 if combo not in seen:                                                           combos2.append(combo)                                                       seen.add(combo)                                                             if len(combos2) >= max_per_batch:
                    break                                                       return combos2                                                          
def generate_combo3_consume(configs, max_per_batch=50):                         combos3 = []                                                                seen = set()
    remaining = configs.copy()                                                  while remaining and len(combos3) < max_per_batch:                               first = remaining.pop(0)
        for i, second in enumerate(remaining):                                          for third in remaining[i+1:]:                                                   tail = third
                if third.startswith("ss://"):                                                   tail = third.split("://", 1)[1]                                             combo = f"{first}+{second}+ss//{tail}"
                else:                                                                           combo = f"{first}+{second}+{third}"                                     if combo not in seen:                                                           combos3.append(combo)
                    seen.add(combo)                                                             if len(combos3) >= max_per_batch:                                               break
            if len(combos3) >= max_per_batch:                                               break                                                               if len(combos3) >= max_per_batch:
            break                                                               return combos3                                                                                                                                      # ------------------ Fragment JSON Builder ------------------               def build_fragment(configs):                                                    fragment = []                                                               for i, cfg in enumerate(configs, 1):                                            host = extract_host(cfg) or "unknown"                                       fragment.append({                                                               "remarks": f"almasi{i}",                                                    "log": {"loglevel": "warning"},                                             "dns": {},                                                                  "inbounds": [],
            "outbounds": [{                                                                 "tag": "proxy",                                                             "protocol": "vless",                                                        "settings": {"vnext": [{"address": host, "port": 443, "users": [{"id": "uuid-placeholder", "encryption": "none", "flow": ""}]}]},
                "streamSettings": {"network": "ws", "security": "tls", "sockopt": {"dialerProxy": "fragment"},
                                   "tlsSettings": {"serverName": host, "fingerprint": "chrome", "alpn": ["http/1.1"]},
                                   "wsSettings": {"path": "/path-placeholder", "headers": {"Host": host}}}
            }],
            "routing": {}
        })
    return json.dumps(fragment, indent=2)

# ------------------ Outputs Menu ------------------
def module_outputs(configs):
    while True:
        print("\n[cyan]Choose output type:[/cyan]")
        print("1) Raw TXT")
        print("2) Base64 Sub")
        print("3) Combo 2")
        print("4) Combo 3")
        print("5) Fragment JSON")
        print("0) Exit")
        choice = input("Enter choice: ").strip()
        if choice == "0":
            break
        elif choice == "1":
            save_file("output_raw.txt", "\n".join(configs))
        elif choice == "2":
            b64 = base64.b64encode("\n".join(configs).encode()).decode()
            save_file("output_base64.txt", b64)
        elif choice == "3":
            combos2 = generate_combo2_consume(configs)
            save_file("output_combo2.txt", "\n".join(combos2))
        elif choice == "4":
            combos3 = generate_combo3_consume(configs)
            save_file("output_combo3.txt", "\n".join(combos3))
        elif choice == "5":
            frag = build_fragment(configs)
            save_file("output_fragment.json", frag)
        else:
            print("[red]Invalid choice[/red]")

# ------------------ MAIN ------------------
if __name__ == "__main__":
    configs = module_input_ping()
    module_outputs(configs)