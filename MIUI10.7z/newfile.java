import os
import re
import subprocess
import base64
import json
import random
from urllib.parse import quote
from rich import print
from rich.table import Table

# ------------------ Settings ------------------
SAVE_DIR = "/sdcard/Download/almasi98/"
os.makedirs(SAVE_DIR, exist_ok=True)

PROTOCOLS = ("vless://", "vmess://", "trojan://", "ss://", "ssss://")
MAX_COMBOS_PER_BATCH = 50  # cap for combo outputs

# ------------------ Module 1: Input + Ping + Stats ------------------
def extract_host(config: str):
    m = re.search(r"@([^:/?#\s]+)", config)
    if m:
        return m.group(1)
    m = re.search(r"://([^:/?#\s]+)", config)
    return m.group(1) if m else None

def ping_host(host: str):
    try:
        out = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        m = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", out)
        return float(m.group(1)) if m else None
    except Exception:
        return None

def classify_ping(avg_ms: float | None):
    if avg_ms is None:
        return "bad", "[bold red][BAD][/bold red]"
    if avg_ms < 150:
        return "good", "[bold green][GOOD][/bold green]"
    if avg_ms < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    return "bad", "[bold red][BAD][/bold red]"

def get_input():
    print("[cyan]Choose input method:[/cyan]")
    print("1) Manual paste configs (Ctrl+D to finish)")
    print("2) Paste a subscription (base64 text)")
    choice = input("Enter choice [1/2]: ").strip()
    lines = []

    if choice == "1":
        print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
        try:
            while True:
                line = input()
                if line.strip():
                    lines.append(line.strip())
        except EOFError:
            pass
    elif choice == "2":
        b64 = input("Paste base64 subscription text: ").strip()
        try:
            decoded = base64.b64decode(b64).decode(errors="ignore")
            lines = [ln.strip() for ln in decoded.splitlines() if ln.strip()]
        except Exception as e:
            print(f"[red]Failed to decode subscription: {e}[/red]")
    else:
        print("[red]Invalid choice.[/red]")

    return lines

def module_input_ping():
    raw = get_input()
    total_raw = len(raw)

    good, warn, bad = [], [], []
    proto_counts = {"vless": 0, "vmess": 0, "trojan": 0, "ss": 0}
    all_valid = []

    print("\n[bold cyan]Pinging hosts...[/bold cyan]\n")
    for cfg in raw:
        if not cfg.startswith(PROTOCOLS):
            continue

        host = extract_host(cfg)
        if not host:
            print(f"[bold red][INVALID][/bold red] {cfg}")
            continue

        avg = ping_host(host)
        status, label = classify_ping(avg)
        ms = f"{avg:.0f}ms" if avg is not None else "NO REPLY"
        print(f"{label} {host} - {ms}")

        if status in ["good", "warn"]:
            all_valid.append(cfg)
            if status == "good":
                good.append(cfg)
            else:
                warn.append(cfg)
        else:
            bad.append(cfg)

        if cfg.startswith("vless://"):
            proto_counts["vless"] += 1
        elif cfg.startswith("vmess://"):
            proto_counts["vmess"] += 1
        elif cfg.startswith("trojan://"):
            proto_counts["trojan"] += 1
        elif cfg.startswith("ss://") or cfg.startswith("ssss://"):
            proto_counts["ss"] += 1

    table = Table(title="Configs Summary")
    table.add_column("Category")
    table.add_column("Count")
    table.add_row("All raw lines", str(total_raw))
    table.add_row("All valid links (good+warn)", str(len(all_valid)))
    table.add_row("Green (GOOD)", str(len(good)))
    table.add_row("Yellow (WARN)", str(len(warn)))
    table.add_row("Red (BAD)", str(len(bad)))
    table.add_row("vless", str(proto_counts["vless"]))
    table.add_row("vmess", str(proto_counts["vmess"]))
    table.add_row("trojan", str(proto_counts["trojan"]))
    table.add_row("ss", str(proto_counts["ss"]))
    print()
    print(table)

    return all_valid

# ------------------ Helpers ------------------
def ask_filename(default_name: str, required_ext: str | None = None):
    name = input(f"Enter filename (default: {default_name}): ").strip()
    if not name:
        name = default_name
    if required_ext and not name.endswith(required_ext):
        name += required_ext
    return os.path.join(SAVE_DIR, name)

def strip_protocol(link: str) -> str:
    if "://" in link:
        return link.split("://", 1)[1]
    return link

# ------------------ Combo Generators ------------------
def generate_combo2(configs: list[str], cap: int = MAX_COMBOS_PER_BATCH) -> list[str]:
    n = len(configs)
    if n < 2:
        return []
    indices = [(i, j) for i in range(n) for j in range(i + 1, n)]
    random.shuffle(indices)
    combos = []
    seen = set()
    for (i, j) in indices:
        combo = f"{configs[i]}+{configs[j]}"
        if combo not in seen:
            combos.append(combo)
            seen.add(combo)
        if len(combos) >= cap:
            break
    return combos

def generate_combo3(configs: list[str], cap: int = MAX_COMBOS_PER_BATCH) -> list[str]:
    n = len(configs)
    if n < 3:
        return []
    cands = []
    for a in range(n):
        for b in range(a + 1, n):
            for c in range(b + 1, n):
                cands.append((a, b, c))
                if len(cands) >= cap * 8:
                    break
            if len(cands) >= cap * 8:
                break
        if len(cands) >= cap * 8:
            break
    random.shuffle(cands)
    combos = []
    seen = set()
    for (i, j, k) in cands:
        A = configs[i]; B = configs[j]; C = configs[k]
        tail = strip_protocol(C)
        combo = f"{A}+{B}+ss//{tail}"
        if combo in seen:
            continue
        seen.add(combo)
        combos.append(combo)
        if len(combos) >= cap:
            break
    return combos

# ------------------ Fragment JSON Builder ------------------
def build_fragment(configs: list[str]) -> str:
    fragment = []
    for i, cfg in enumerate(configs, 1):
        host = extract_host(cfg) or "unknown"
        fragment.append({
            "remarks": f"almasi{i}",
            "log": {"loglevel": "warning"},
            "dns": {},
            "inbounds": [],
            "outbounds": [{
                "tag": "proxy",
                "protocol": "vless",
                "settings": {"vnext": [{"address": host, "port": 443, "users": [{"id": "uuid-placeholder", "encryption": "none", "flow": ""}]}]},
                "streamSettings": {
                    "network": "ws",
                    "security": "tls",
                    "sockopt": {"dialerProxy": "fragment"},
                    "tlsSettings": {"serverName": host, "fingerprint": "chrome", "alpn": ["http/1.1"]},
                    "wsSettings": {"path": "/path-placeholder", "headers": {"Host": host}}
                }
            }],
            "routing": {}
        })
    return json.dumps(fragment, indent=2, ensure_ascii=False)

# ------------------ Module 2: Outputs Menu ------------------
def outputs_menu(configs: list[str]):
    while True:
        print("\n[cyan]Choose output type:[/cyan]")
        print("1) Raw TXT (accepted links)")
        print("2) Base64 Sub")
        print("3) Combo-2 (TXT)")
        print("4) Combo-3 (TXT)")
        print("5) Fragment JSON")
        print("0) Exit")

        choice = input("Enter choice: ").strip()

        if choice == "0":
            break

        elif choice == "1":
            path = ask_filename("raw.txt", ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(configs))
            print(f"[green]Saved:[/green] {path}")

        elif choice == "2":
            b64 = base64.b64encode("\n".join(configs).encode()).decode()
            path = ask_filename("subscription.txt", ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write(b64)
            print(f"[green]Saved base64 subscription:[/green] {path}")

        elif choice == "3":
            combos2 = generate_combo2(configs, MAX_COMBOS_PER_BATCH)
            path = ask_filename("combo2.txt", ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(combos2))
            print(f"[green]Saved Combo-2 ({len(combos2)}):[/green] {path}")

        elif choice == "4":
            combos3 = generate_combo3(configs, MAX_COMBOS_PER_BATCH)
            path = ask_filename("combo3.txt", ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(combos3))
            print(f"[green]Saved Combo-3 ({len(combos3)}):[/green] {path}")

        elif choice == "5":
            frag = build_fragment(configs)
            path = ask_filename("fragment.json", ".json")
            with open(path, "w", encoding="utf-8") as f:
                f.write(frag)
            print(f"[green]Saved Fragment JSON:[/green] {path}")

        else:
            print("[red]Invalid choice.[/red]")

# ------------------ MAIN ------------------
if __name__ == "__main__":
    accepted = module_input_ping()
    outputs_menu(accepted)