import os
import re
import subprocess
import requests
import json
import random
from urllib.parse import quote
from rich import print

# ---------- رنگ‌ها ----------
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"

protocols = ["vmess://", "vless://", "trojan://", "ss://"]

# ---------- توابع اصلی ----------
def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None:
        return "red", f"{RED}✖ BAD{RESET}"
    elif ping < 150:
        return "green", f"{GREEN}✔ GOOD{RESET}"
    elif ping < 300:
        return "yellow", f"{YELLOW}⚠ WARN{RESET}"
    else:
        return "red", f"{RED}✖ BAD{RESET}"

def fetch_sub_link(url):
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        content = r.text
        content = ''.join([c for c in content if ord(c) < 128])
        return content
    except Exception as e:
        print(f"{RED}❌ Failed to fetch: {url}\nError: {e}{RESET}")
        return None

def parse_configs(raw_data):
    lines = raw_data.splitlines()
    configs = [line.strip() for line in lines if line.strip()]
    return configs

def categorize_configs(configs):
    vless, trojan, ss, others = [], [], [], []
    for cfg in configs:
        lower = cfg.lower()
        if "vless://" in lower:
            vless.append(cfg)
        elif "trojan://" in lower:
            trojan.append(cfg)
        elif "ss://" in lower:
            ss.append(cfg)
        else:
            others.append(cfg)
    return vless, trojan, ss, others

# ---------- ذخیره فایل ----------
def save_to_file(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        for d in data:
            f.write(d + "\n")
    print(f"{GREEN}✅ Saved file: {os.path.abspath(filename)}{RESET}")

def save_json(filename, data):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"{GREEN}✅ Saved JSON: {os.path.abspath(filename)}{RESET}")

# ---------- فرگمنت دقیق ----------
def build_fragment_list(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        host = extract_host(cfg) or "0.0.0.0"
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": host,
                    "port": 443,
                    "users": [{"id": "uuid-placeholder", "encryption": "none", "flow": ""}]
                }]
            },
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {"serverName": host, "fingerprint": "chrome", "alpn": ["http/1.1"]},
                "wsSettings": {"path": "/", "headers": {"Host": host}}
            }
        }
        fragment = {
            "remarks": f"Config {i+1}",
            "log": {"loglevel": "warning"},
            "dns": {},
            "inbounds": [],
            "outbounds": [outbound],
            "routing": {}
        }
        fragments.append(fragment)
    return fragments

# ---------- خروجی ترکیبی 3 و 2 دقیق ----------
def generate_3combo(configs, max_count=50):
    if len(configs) < 3:
        return []
    combos = []
    seen = set()
    while len(combos) < min(max_count, len(configs)**3):
        a, b, c = random.sample(configs, 3)
        combo = f"{a}+{b}+{c}"
        if combo not in seen:
            combos.append(combo)
            seen.add(combo)
    return combos

def generate_2combo(configs, max_count=50):
    if len(configs) < 2:
        return []
    combos = []
    seen = set()
    while len(combos) < min(max_count, len(configs)**2):
        a, b = random.sample(configs, 2)
        combo = f"{a}+{b}"
        if combo not in seen:
            combos.append(combo)
            seen.add(combo)
    return combos

# ---------- اجرای اصلی ----------
def main():
    all_configs = []

    print("[cyan]Choose input method:[/cyan]")
    print("1) Manual input (Ctrl+D to finish)")
    print("2) Fetch from subscription URL")
    choice = input("Enter choice (1 or 2): ").strip()

    if choice == "1":
        print("[cyan]Paste your configs line by line. Press Ctrl+D to finish:[/cyan]")
        try:
            while True:
                line = input()
                if line.strip():
                    all_configs.append(line.strip())
        except EOFError:
            pass
    elif choice == "2":
        while True:
            url = input("Enter subscription URL: ").strip()
            data = fetch_sub_link(url)
            if data:
                new_cfgs = parse_configs(data)
                all_configs.extend(new_cfgs)
                print(f"{GREEN}✅ Fetched {len(new_cfgs)} configs{RESET}")
            more = input("Add another link? (y/n): ").strip().lower()
            if more != "y":
                break
    else:
        print("Invalid choice.")
        return

    all_configs = list(set(all_configs))
    vless, trojan, ss, others = categorize_configs(all_configs)

    print(f"\nTotal configs: {len(all_configs)}")
    print(f"VLESS: {len(vless)}")
    print(f"TROJAN: {len(trojan)}")
    print(f"SHADOWSOCKS: {len(ss)}")
    print(f"Others: {len(others)}")

    green, yellow, red = [], [], []

    print("\nPerforming ping checks...")
    for config in all_configs:
        host = extract_host(config)
        if not host:
            print(f"{RED}[INVALID] {config}{RESET}")
            continue
        ping_val = ping_host(host)
        status, label = classify_ping(ping_val)
        print(f"{label} {host} - {ping_val if ping_val else 'NO REPLY'}ms")
        if status == "green":
            green.append(config)
        elif status == "yellow":
            yellow.append(config)
        else:
            red.append(config)

    folder = "/storage/emulated/0/Download/Akbar98"
    os.makedirs(folder, exist_ok=True)

    while True:
        print("\nChoose output:")
        print("1) VLESS only")
        print("2) TROJAN only")
        print("3) SHADOWSOCKS only")
        print("4) All configs")
        print("5) Green ping only")
        print("6) Green + Yellow ping")
        print("7) Fragmented Configs (V2Ray) [New]")
        print("8) Save all as JSON")
        print("9) Generate 3-combo [New]")
        print("10) Generate 2-combo [New]")
        print("0) Exit")
        option = input("Enter option number: ").strip()

        if option == "0":
            break
        elif option == "1":
            fname = input("Enter filename for VLESS (txt): ").strip() or "output_vless.txt"
            save_to_file(os.path.join(folder, fname), vless)
        elif option == "2":
            fname = input("Enter filename for TROJAN (txt): ").strip() or "output_trojan.txt"
            save_to_file(os.path.join(folder, fname), trojan)
        elif option == "3":
            fname = input("Enter filename for SHADOWSOCKS (txt): ").strip() or "output_ss.txt"
            save_to_file(os.path.join(folder, fname), ss)
        elif option == "4":
            fname = input("Enter filename for ALL configs (txt): ").strip() or "output_all.txt"
            save_to_file(os.path.join(folder, fname), all_configs)
        elif option == "5":
            fname = input("Enter filename for GREEN ping (txt): ").strip() or "output_green.txt"
            save_to_file(os.path.join(folder, fname), green)
        elif option == "6":
            fname = input("Enter filename for GREEN+YELLOW ping (txt): ").strip() or "output_green_yellow.txt"
            save_to_file(os.path.join(folder, fname), green + yellow)
        elif option == "7":
            fname = input("Enter filename for Fragment JSON: ").strip() or "fragmented_configs.json"
            fragments = build_fragment_list(all_configs)
            save_json(os.path.join(folder, fname), fragments)
        elif option == "8":
            fname = input("Enter filename for ALL JSON: ").strip() or "all_configs.json"
            save_json(os.path.join(folder, fname), all_configs)
        elif option == "9":
            combos3 = generate_3combo(all_configs)
            fname = input("Enter filename for 3-combo: ").strip() or "combo_3.txt"
            save_to_file(os.path.join(folder, fname), combos3)
        elif option == "10":
            combos2 = generate_2combo(all_configs)
            fname = input("Enter filename for 2-combo: ").strip() or "combo_2.txt"
            save_to_file(os.path.join(folder, fname), combos2)
        else:
            print(f"{RED}Invalid option.{RESET}")

if __name__ == "__main__":
    main()