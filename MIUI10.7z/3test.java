#!/data/data/com.termux/files/usr/bin/bash

# مسیر ذخیره خروجی
OUTPUT_DIR="/sdcard/Download/almasi98"
mkdir -p "$OUTPUT_DIR"

# رنگ‌ها
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# منوی اصلی
main_menu() {
    echo -e "${YELLOW}========== Network Test Menu ==========${NC}"
    echo -e "1) ICMP Test"
    echo -e "2) TCP Test"
    echo -e "3) URL / HTTP Test"
    echo -e "4) Run All Tests (ICMP + TCP + URL)"
    echo -e "0) Exit"
    echo -n "Choose an option: "
    read option
    case $option in
        1) protocol="ICMP" ;;
        2) protocol="TCP" ;;
        3) protocol="URL" ;;
        4) protocol="ALL" ;;
        0) exit 0 ;;
        *) echo -e "${RED}Invalid option${NC}"; main_menu ;;
    esac
}

# گرفتن ورودی‌ها
get_targets() {
    echo -e "${YELLOW}Enter each target (SS/VMess/URL) per line. Press Ctrl+D when done:${NC}"
    targets=()
    while read line; do
        [ -n "$line" ] && targets+=("$line")
    done
}

# گرفتن نام فایل خروجی
get_output_file() {
    echo -n "Enter output file name (without extension): "
    read filename
    output_path="$OUTPUT_DIR/${filename}.txt"
    > "$output_path"
}

# پیشنهادات ICMP
icmp_suggestions() {
    echo -e "${YELLOW}Choose ICMP test type:${NC}"
    echo "1) Fast (5 packets, 3s timeout)"
    echo "2) Medium (10 packets, 5s timeout)"
    echo "3) Precise (20 packets, 7s timeout)"
    echo "4) Custom"
    echo -n "Select an option: "
    read choice
    case $choice in
        1) icmp_count=5; icmp_timeout=3 ;;
        2) icmp_count=10; icmp_timeout=5 ;;
        3) icmp_count=20; icmp_timeout=7 ;;
        4) 
            echo -n "Enter number of packets: "; read icmp_count
            echo -n "Enter timeout per packet (seconds): "; read icmp_timeout
            ;;
        *) echo -e "${RED}Invalid choice${NC}"; icmp_suggestions ;;
    esac
}

# پیشنهادات TCP
tcp_suggestions() {
    echo -e "${YELLOW}Enter TCP ports separated by space (default 443):${NC}"
    read ports
    [ -z "$ports" ] && ports="443"
    tcp_ports=($ports)

    echo -e "${YELLOW}Choose TCP timeout suggestion:${NC}"
    echo "1) Fast (2s)"
    echo "2) Medium (5s)"
    echo "3) Precise (10s)"
    echo "4) Custom"
    echo -n "Select an option: "
    read choice
    case $choice in
        1) tcp_timeout=2 ;;
        2) tcp_timeout=5 ;;
        3) tcp_timeout=10 ;;
        4) 
            echo -n "Enter timeout per connection (seconds): "; read tcp_timeout
            ;;
        *) echo -e "${RED}Invalid choice${NC}"; tcp_suggestions ;;
    esac
}

# پیشنهادات URL/HTTP
url_suggestions() {
    echo -e "${YELLOW}Choose URL test type:${NC}"
    echo "1) Fast (1 request, 3s timeout)"
    echo "2) Medium (3 requests, 5s timeout)"
    echo "3) Precise (5 requests, 7s timeout)"
    echo "4) Custom"
    echo -n "Select an option: "
    read choice
    case $choice in
        1) url_count=1; url_timeout=3 ;;
        2) url_count=3; url_timeout=5 ;;
        3) url_count=5; url_timeout=7 ;;
        4)
            echo -n "Enter number of requests: "; read url_count
            echo -n "Enter timeout per request: "; read url_timeout
            ;;
        *) echo -e "${RED}Invalid choice${NC}"; url_suggestions ;;
    esac
}

# تست ICMP
test_icmp() {
    icmp_suggestions
    echo -e "${YELLOW}Running ICMP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        ping -c $icmp_count -W $icmp_timeout $host &> /dev/null
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}ICMP Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}ICMP Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

# تست TCP
test_tcp() {
    tcp_suggestions
    echo -e "${YELLOW}Running TCP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        host=$(echo "$target" | awk -F@ '{print $2}' | awk -F: '{print $1}')
        tcp_success=true
        for port in "${tcp_ports[@]}"; do
            nc -z -w $tcp_timeout $host $port &> /dev/null
            if [ $? -ne 0 ]; then
                echo -e "${RED}TCP Failed: $target on port $port${NC}"
                tcp_success=false
            else
                echo -e "${GREEN}TCP Success: $target on port $port${NC}"
            fi
        done
        $tcp_success && success_targets+=("$target")
    done
    targets=("${success_targets[@]}")
}

# تست URL / HTTP
test_url() {
    url_suggestions
    echo -e "${YELLOW}Running URL/HTTP tests...${NC}"
    success_targets=()
    for target in "${targets[@]}"; do
        url_success=true
        for i in $(seq 1 $url_count); do
            curl -o /dev/null -s -m $url_timeout $target
            if [ $? -ne 0 ]; then
                url_success=false
                break
            fi
        done
        if $url_success; then
            echo -e "${GREEN}URL Success: $target${NC}"
            success_targets+=("$target")
        else
            echo -e "${RED}URL Failed: $target${NC}"
        fi
    done
    targets=("${success_targets[@]}")
}

# حلقه اصلی
while true; do
    main_menu
    get_targets
    get_output_file

    case $protocol in
        ICMP) test_icmp ;;
        TCP) test_tcp ;;
        URL) test_url ;;
        ALL)
            test_icmp
            test_tcp
            test_url
            ;;
    esac

    # ذخیره کانفیگ‌های سالم
    for target in "${targets[@]}"; do
        echo "$target" >> "$output_path"
    done

    echo -e "${YELLOW}Test completed. Only the best configurations saved to $output_path${NC}"
    echo -e "Press Enter to return to the main menu for another test..."
    read
done