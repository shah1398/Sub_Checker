SHA256:3Bo2VmrEeYVJPVUH2tkt/waELZPa0jFA43OToxuDUI8 tepo18@example.com

tepo18


ssh-keygen -t ed25519 -C "tepo18@example.com"



دستوراول برای دریافت وساخت رمزssh

eval "$(ssh-agent -s)"
دستوردم

ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBpPWqL0YD1FV7M+Y/4nvFSLiZ1n0XELo7MjQ3jQCp2o tepo18@example.com

کلیدعمومی 



کلیدخصوصی 

SHA256:OManhKh0/5Fnps+rTYkgRVjVJUMhiZMSfEa06b2C0DU tepo18@example.com


اکانت 18


دستورات مهم



SHA256:NZ+Z8E7TPxWsuO6GY7YUIRsirQ1nO1FhU5tG0cDmN1M almasi98@example.com

کلیدخصوصی ssh
اکانت دومalmasi98

ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBpPWqL0YD1FV7M+Y/4nvFSLiZ1n0XELo7MjQ3jQCp2o tepo18@example.com



ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBhrdBrKf04o4oN5QS7z4SN2zDAj+O9wHg3yy5/tpA4J almasi98@example.com


عمومی رمز



SHA256:NZ+Z8E7TPxWsuO6GY7YUIRsirQ1nO1FhU5tG0cDmN1M almasi98@example.com

خصوصی


رمز اکانت گیت   almasi98
Akbar909090







ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIN/SMP9g7MEZOdPYOOZ1/mR7gbSUdPlh7U96JkSqsnZN ahsan-tepo1383@example.com


رمزعمومی اکانت   ahsan-tepo1383

SHA256:8hg3oNCtH7eUQDrTMqjkWdQjsHksliOQCpuTPJXEWSY ahsan-tepo1383@example.com

رمزخصوصی 


