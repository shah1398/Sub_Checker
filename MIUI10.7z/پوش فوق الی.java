#!/bin/bash

# ------------------- COLORS -------------------
CYAN="\e[36m"
GREEN="\e[32m"
YELLOW="\e[33m"
RESET="\e[0m"

# ------------------- PATHS -------------------
BASE_PATH="$HOME"
DOWNLOAD_DIR="/sdcard/Download/Akbar98"
CRED_DIR="$HOME/.git-credentials-accounts"
mkdir -p "$CRED_DIR"

# ------------------- CREDENTIAL SETUP -------------------
credential_setup() {
    echo -e "${CYAN}GitHub Credential Setup:${RESET}"
    echo "1) Change username (keep saved token)"
    echo "2) Use saved credentials or save new permanently"
    echo "3) Edit username and/or token"
    echo -ne "${CYAN}Enter choice (1, 2, or 3): ${RESET}"
    read -r CREDS_CHOICE

    echo -ne "${CYAN}Enter account name to use: ${RESET}"
    read -r ACCOUNT_NAME
    CRED_FILE="$CRED_DIR/$ACCOUNT_NAME"

    # تابع استخراج یوزرنیم و توکن
    get_credentials() {
        if [ -f "$CRED_FILE" ]; then
            GIT_USER=$(sed -n 's#https://\([^:]*\):.*#\1#p' "$CRED_FILE")
            GIT_TOKEN=$(sed -n 's#https://[^:]*:\([^@]*\)@.*#\1#p' "$CRED_FILE")
        else
            GIT_USER=""
            GIT_TOKEN=""
        fi
    }

    case "$CREDS_CHOICE" in
        1)
            get_credentials
            if [ -z "$GIT_TOKEN" ]; then
                echo -e "${YELLOW}No saved token found. Please choose option 2 first.${RESET}"
                exit 1
            fi
            echo -ne "${CYAN}Enter NEW GitHub username: ${RESET}"
            read -r NEW_USER
            echo "https://$NEW_USER:$GIT_TOKEN@github.com" > "$CRED_FILE"
            chmod 600 "$CRED_FILE"
            echo -e "${GREEN}Username updated. Token kept same.${RESET}"
            ;;
        2)
            if [ ! -f "$CRED_FILE" ]; then
                echo -ne "${CYAN}Enter GitHub username: ${RESET}"
                read -r GIT_USER
                echo -ne "${CYAN}Enter GitHub token: ${RESET}"
                read -rs GIT_TOKEN
                echo
                echo "https://$GIT_USER:$GIT_TOKEN@github.com" > "$CRED_FILE"
                chmod 600 "$CRED_FILE"
                echo -e "${GREEN}Credentials saved permanently.${RESET}"
            else
                get_credentials
                echo -e "${GREEN}Using saved credentials for account '$ACCOUNT_NAME' ($GIT_USER).${RESET}"
            fi
            ;;
        3)
            get_credentials
            echo -ne "${CYAN}Do you want to change username? (yes/no): ${RESET}"
            read -r CHANGE_USER
            if [ "$CHANGE_USER" == "yes" ]; then
                echo -ne "${CYAN}Enter NEW GitHub username: ${RESET}"
                read -r GIT_USER
            fi
            echo -ne "${CYAN}Do you want to change token? (yes/no): ${RESET}"
            read -r CHANGE_TOKEN
            if [ "$CHANGE_TOKEN" == "yes" ]; then
                echo -ne "${CYAN}Enter NEW GitHub token: ${RESET}"
                read -rs GIT_TOKEN
                echo
            fi
            echo "https://$GIT_USER:$GIT_TOKEN@github.com" > "$CRED_FILE"
            chmod 600 "$CRED_FILE"
            echo -e "${GREEN}Credentials updated successfully.${RESET}"
            ;;
        *)
            echo -e "${YELLOW}Invalid choice. Exiting.${RESET}"
            exit 1
            ;;
    esac

    # تنظیم credential helper
    git config --global credential.helper "store --file=$CRED_FILE"
}

credential_setup

# ------------------- REPO SETUP -------------------
echo -ne "${CYAN}Enter repo name to clone/use: ${RESET}"
read -r REPO_NAME
REPO_PATH="$BASE_PATH/$REPO_NAME"

if [ ! -d "$REPO_PATH" ]; then
    echo -e "${GREEN}Cloning repo...${RESET}"
    git clone "https://github.com/$GIT_USER/$REPO_NAME.git" "$REPO_PATH" || { echo "Clone failed!"; exit 1; }
else
    echo -e "${GREEN}Repo folder exists. Using existing repo.${RESET}"
fi

cd "$REPO_PATH" || { echo "Cannot enter repo folder."; exit 1; }

# ------------------- MAIN MENU -------------------
while true; do
    echo -e "\n${CYAN}Select an option:${RESET}"
    echo "1) Create new file"
    echo "2) Edit existing file"
    echo "3) Delete a file"
    echo "4) Commit changes"
    echo "5) Push to GitHub (with sublinks)"
    echo "6) Copy content from download folder to repo file"
    echo "7) Run checker scripts"
    echo "8) Help"
    echo "9) Exit"
    echo -ne "${CYAN}Choice: ${RESET}"
    read -r CHOICE

    case $CHOICE in
        1)
            echo -ne "${CYAN}Enter new filename to create: ${RESET}"
            read -r NEWFILE
            if [ -e "$NEWFILE" ]; then
                echo -e "${YELLOW}File already exists.${RESET}"
            else
                touch "$NEWFILE"
                echo -e "${GREEN}File '$NEWFILE' created.${RESET}"
            fi
            ;;
        2)
            echo -ne "${CYAN}Enter filename to edit: ${RESET}"
            read -r EDITFILE
            if [ ! -e "$EDITFILE" ]; then
                echo -e "${YELLOW}File does not exist.${RESET}"
            else
                nano "$EDITFILE"
            fi
            ;;
        3)
            echo -ne "${CYAN}Enter filename to delete: ${RESET}"
            read -r DELFILE
            if [ ! -e "$DELFILE" ]; then
                echo -e "${YELLOW}File does not exist.${RESET}"
            else
                rm -i "$DELFILE"
                echo -e "${GREEN}File deleted.${RESET}"
            fi
            ;;
        4)
            git status
            echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
            read -r MSG
            git add .
            [ -z "$MSG" ] && MSG="auto update from script"
            git commit -m "$MSG" 2>/dev/null || echo -e "${YELLOW}Nothing to commit.${RESET}"
            ;;
        5)
            echo -ne "${CYAN}Push changes to GitHub? (yes/no): ${RESET}"
            read -r PUSH_ANSWER
            if [ "$PUSH_ANSWER" == "yes" ]; then
                branch_name=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
                [ "$branch_name" = "HEAD" ] && branch_name="auto-push-branch" && git switch -c "$branch_name"
                git add -A
                echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
                read -r MSG
                [ -z "$MSG" ] && MSG="auto update from script"
                git commit -m "$MSG" --allow-empty
                git push "https://github.com/$GIT_USER/$REPO_NAME.git" --force && echo -e "${GREEN}Pushed successfully.${RESET}" || echo -e "${YELLOW}Push failed.${RESET}"

                # ذخیره لینک‌ها
                echo "" > links.md
                CHANGED_FILES=$(git diff --name-only HEAD~1)
                for FILE in $CHANGED_FILES; do
                    RAW_URL="https://raw.githubusercontent.com/$GIT_USER/$REPO_NAME/main/$FILE"
                    echo "$RAW_URL" >> links.md
                done
                LAST_LINK=$(tail -n 1 links.md)
                [ -n "$LAST_LINK" ] && echo -e "${CYAN}Last sublink saved in links.md:${RESET} $LAST_LINK"
            else
                echo "Push canceled."
            fi
            ;;
        6)
            echo -ne "${CYAN}Enter source filename inside download folder ($DOWNLOAD_DIR): ${RESET}"
            read -r SRCFILE
            SRC_PATH="$DOWNLOAD_DIR/$SRCFILE"
            if [ ! -f "$SRC_PATH" ]; then
                echo -e "${YELLOW}Source file '$SRC_PATH' not found.${RESET}"
                continue
            fi
            echo -ne "${CYAN}Enter target filename inside repo folder: ${RESET}"
            read -r TARGETFILE
            cat "$SRC_PATH" > "$TARGETFILE"
            echo -e "${GREEN}Content from '$SRC_PATH' copied to '$TARGETFILE'.${RESET}"
            ;;
        7)
            echo -e "${CYAN}Select which cl to run:${RESET}"
            echo "1) cl.py (repo: sab-vip10)"
            echo "2) cl2.py (repo: sab-vip10)"
            echo "3) cl.py (repo: reza-shah1320)"
            echo -ne "${CYAN}Choice: ${RESET}"
            read -r CHEK_CHOICE
            case $CHEK_CHOICE in
                1|2|3)
                    SCRIPT="./cl.py"
                    [ ! -f "$SCRIPT" ] && echo -e "${YELLOW}$SCRIPT not found.${RESET}" && continue
                    echo -e "${GREEN}Running $SCRIPT...${RESET}"
                    python3 "$SCRIPT"
                    ;;
                *)
                    echo -e "${YELLOW}Invalid choice!${RESET}"
                    ;;
            esac
            ;;
        8)
            echo -e "${CYAN}Help - Main Commands:${RESET}"
            echo "1) Create a new file"
            echo "2) Edit an existing file"
            echo "3) Delete a file"
            echo "4) Commit changes"
            echo "5) Push to GitHub and generate sublinks"
            echo "6) Copy file from download folder to repo"
            echo "7) Run checker scripts"
            echo "8) Show this help menu"
            echo "9) Exit script"
            ;;
        9)
            echo "Exiting."
            exit 0
            ;;
        *)
            echo -e "${YELLOW}Invalid choice!${RESET}"
            ;;
    esac
done