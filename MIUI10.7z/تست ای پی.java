import os
import requests
from icmplib import ping as pinging
from rich.console import Console
from rich.table import Table
from concurrent.futures import ThreadPoolExecutor

console = Console()
results = []

# مسیر فایل IP ثابت
ip_file = '/storage/emulated/0/Download/Akbar98/ip4.txt'

# بررسی اتصال اینترنت
def check_internet_connection():
    try:
        requests.get('http://www.google.com/', timeout=5)
        return True
    except requests.ConnectionError:
        return False

# دریافت جزئیات کشور IP
def get_ip_details(ip_address):
    try:
        response = requests.get(f'http://ip-api.com/json/{ip_address}', timeout=10)
        return response.json().get('countryCode', 'N/A')
    except Exception:
        return 'N/A'

# ایجاد محدوده IP
def create_ip_range(start_ip, end_ip):
    start = list(map(int, start_ip.split('.')))
    end = list(map(int, end_ip.split('.')))
    temp = start[:]
    ip_range = []
    while temp != end:
        ip_range.append('.'.join(map(str, temp)))
        temp[3] += 1
        for i in (3, 2, 1):
            if temp[i] == 256:
                temp[i] = 0
                temp[i-1] += 1
    ip_range.append(end_ip)
    return ip_range

# اسکن IP
def scan_ip_port(ip, results, loc):
    try:
        icmp = pinging(ip, count=1, interval=1, timeout=3, privileged=False)
        results.append((ip, loc, float(icmp.avg_rtt), icmp.packet_loss, icmp.jitter))
    except:
        results.append((ip, loc, 1000.0, 100.0, 1000.0))

# خواندن فایل ورودی و تشخیص نوع خط
def read_ip_file():
    ips = []
    if not os.path.exists(ip_file):
        console.print(f"[bold red]IP file not found: {ip_file}[/bold red]")
        exit()
    with open(ip_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if ':' in line:
                parts = line.split(':')
                if len(parts) == 2 and all(p.count('.') == 3 for p in parts):
                    start, end = parts
                    ips.append(('range', start, end))
                else:
                    ip = parts[0]
                    ips.append(('single', ip))
            else:
                ips.append(('single', line))
    return ips

def main():
    if not check_internet_connection():
        console.print("[bold red]Internet not available[/bold red]")
        exit()

    ip_entries = read_ip_file()
    if not ip_entries:
        console.print("[bold red]No valid IPs found[/bold red]")
        exit()

    # پردازش IPها
    for entry in ip_entries:
        if entry[0] == 'single':
            ip = entry[1]
            loc = get_ip_details(ip)
            executor = ThreadPoolExecutor(max_workers=20)
            executor.submit(scan_ip_port, ip, results, loc)
            executor.shutdown(wait=True)
        elif entry[0] == 'range':
            start_ip, end_ip = entry[1], entry[2]
            loc = get_ip_details(start_ip)
            ip_range = create_ip_range(start_ip, end_ip)
            executor = ThreadPoolExecutor(max_workers=20)
            futures = [executor.submit(scan_ip_port, ip, results, loc) for ip in ip_range]
            executor.shutdown(wait=True)

    # محاسبه score و مرتب‌سازی
    extended_results = []
    for ip, loc, ping, loss_rate, jitter in results:
        if ping == 0.0: ping = 1000
        if jitter == 0.0: jitter = 1000
        if loss_rate == 1.0: loss_rate = 1000
        loss_rate *= 100
        combined_score = 0.5 * ping + 0.3 * loss_rate + 0.2 * jitter
        extended_results.append((ip, loc, ping, loss_rate, jitter, combined_score))

    sorted_results = sorted(extended_results, key=lambda x: x[5])

    # نمایش جدول
    table = Table(show_header=True, title="IP Scan Results", header_style="bold blue")
    table.add_column("IP", width=15)
    table.add_column("Loc", width=3)
    table.add_column("Ping (ms)", justify="right")
    table.add_column("Packet Loss (%)", justify="right")
    table.add_column("Jitter (ms)", justify="right")
    table.add_column("Score", justify="right")

    for ip, loc, ping, loss_rate, jitter, combined_score in sorted_results:
        table.add_row(ip, loc, f"{ping:.2f}", f"{loss_rate:.2f}%", f"{jitter:.2f}", f"{combined_score:.2f}")

    console.print(table)

    # پرسش نام فایل خروجی
    filename = input("\nEnter output file name (without extension): ")
    output_path = f"/storage/emulated/0/Download/Akbar98/{filename}.csv"
    best_output_path = f"/storage/emulated/0/Download/Akbar98/best_{filename}.csv"

    # ذخیره خروجی کامل
    with open(output_path, "w") as f:
        f.write("IP,Location,Ping,Packet Loss,Jitter,Score\n")
        for ip, loc, ping, loss_rate, jitter, combined_score in sorted_results:
            f.write(f"{ip}    ,{loc}   ,{ping:.2f},{loss_rate:.2f},{jitter:.2f},{combined_score:.2f}\n")
    console.print(f"\nSaved all results to: [bold green]{output_path}[/bold green]")

    # ذخیره بهترین 5 IP
    with open(best_output_path, "w") as f:
        f.write("IP,Location,Ping,Packet Loss,Jitter,Score\n")
        for ip, loc, ping, loss_rate, jitter, combined_score in sorted_results[:5]:
            f.write(f"{ip}    ,{loc}   ,{ping:.2f},{loss_rate:.2f},{jitter:.2f},{combined_score:.2f}\n")
    console.print(f"Saved top 5 best IPs to: [bold green]{best_output_path}[/bold green]")

    console.print("\nTop 5 suggested IPs:")
    for ip, loc, ping, loss_rate, jitter, combined_score in sorted_results[:5]:
        console.print(f"[bold cyan]{ip}[/bold cyan] | Loc: {loc} | Ping: {ping:.2f} ms | Loss: {loss_rate:.2f}% | Jitter: {jitter:.2f} | Score: {combined_score:.2f}")

if __name__ == "__main__":
    main()