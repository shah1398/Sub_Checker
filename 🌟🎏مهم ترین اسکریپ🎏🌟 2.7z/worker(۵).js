export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // ---------- Helpers ----------
    function getCookie(request, name) {
      const cookie = request.headers.get("Cookie") || "";
      const m = cookie.match(new RegExp("(^|; )" + name + "=([^;]+)"));
      return m ? decodeURIComponent(m[2]) : null;
    }
    function setCookieHeader(name, value, maxAge = 3600) {
      return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
    }
    function redirect(location, extraHeaders = {}) {
      return new Response(null, { status: 302, headers: { Location: location, ...extraHeaders } });
    }
    async function getEffectivePass(env) {
      // KV override
      const o = await env.SUBS.get("cfg:pass");
      return o || (env.PANEL_PASS || "12345678");
    }
    async function getEffectiveUUID(env) {
      const o = await env.SUBS.get("cfg:uuid");
      return o || (env.UUID || "00000000-0000-0000-0000-000000000000");
    }

    // ---------- HTML pages ----------
    const styles = `
      :root{
        --bg: #0f172a;
        --card:#111827;
        --muted:#9ca3af;
        --accent:#0ea5e9;
        --ok:#22c55e;
        --warn:#f59e0b;
        --danger:#ef4444;
        --text:#e5e7eb;
      }
      *{box-sizing:border-box}
      html,body{height:100%}
      body{
        margin:0;font-family:Inter,Segoe UI,Arial,sans-serif;
        background:linear-gradient(180deg,#0b1220,#0f172a 60%);
        color:var(--text);display:flex;align-items:center;justify-content:center;
        padding:24px;
      }
      .wrap{width:100%;max-width:980px}
      .card{
        background:linear-gradient(180deg,#0b1220,#0f172a);
        border:1px solid rgba(255,255,255,.06);
        border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,.4);
        padding:22px;margin-bottom:16px
      }
      h1,h2,h3{margin:.4rem 0 1rem}
      h1{font-size:28px}
      h2{font-size:20px}
      .muted{color:var(--muted);font-size:.9rem}
      input,select,textarea{
        width:100%;background:#0b1220;border:1px solid rgba(255,255,255,.08);
        color:var(--text);padding:10px 12px;border-radius:10px;outline:none;
      }
      textarea{min-height:120px}
      .row{display:flex;gap:12px;flex-wrap:wrap;margin-top:10px}
      .col{flex:1;min-width:220px}
      .btn{
        padding:10px 14px;border:0;border-radius:10px;cursor:pointer;
        background:var(--accent);color:#fff;font-weight:600
      }
      .btn.sec{background:#334155}
      .btn.warn{background:var(--warn)}
      .btn.danger{background:var(--danger)}
      .btn.ok{background:var(--ok)}
      .topbar{display:flex;align-items:center;gap:12px;justify-content:space-between;margin-bottom:14px}
      .pill{
        background:#0b1220;border:1px dashed rgba(255,255,255,.1);
        border-radius:999px;padding:8px 12px;font-size:13px;color:var(--muted)
      }
      code{background:#0b1220;border:1px solid rgba(255,255,255,.08);padding:6px;border-radius:8px}
      .grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
      @media(max-width:820px){.grid{grid-template-columns:1fr}}
      .center{display:flex;align-items:center;justify-content:center}
      .title{
        font-weight:800;font-size:30px;
        background: linear-gradient(90deg,#60a5fa,#34d399,#22d3ee);
        -webkit-background-clip: text;background-clip:text;color:transparent;
        margin:0 0 6px;
      }
      .subtitle{color:var(--muted);margin:0 0 16px}
      .footer{color:#64748b;font-size:12px;text-align:center;margin-top:6px}
      .copyRow{display:flex;gap:8px;align-items:center}
      .small{font-size:13px;color:var(--muted)}
      .sep{height:1px;background:rgba(255,255,255,.06);margin:10px 0}
      .right{display:flex;gap:8px;align-items:center}
      .dangerText{color:var(--danger)}
    `;

    function htmlLogin() {
      return new Response(
        `<!DOCTYPE html><html lang="fa"><head>
          <meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
          <title>Login · Semi-Pro Panel</title>
          <style>${styles}</style>
        </head><body>
          <div class="wrap">
            <div class="card center" style="max-width:460px;margin:0 auto;">
              <div style="width:100%;max-width:360px">
                <h1 class="title">My Semi-Pro Panel</h1>
                <div class="subtitle">برای ورود رمز پنل را وارد کنید.</div>
                <form method="POST" action="/login">
                  <label>Panel Password</label>
                  <input name="pass" type="password" placeholder="••••••••" required />
                  <div class="row" style="margin-top:12px">
                    <div class="col">
                      <button class="btn" type="submit">ورود</button>
                    </div>
                    <div class="col right">
                      <span class="pill">راهکار: اگر رمز را فراموش کردید، متغیر PANEL_PASS را در تنظیمات Worker تغییر دهید.</span>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div class="footer">Cloudflare Worker · KV + Auth · Dark UI</div>
          </div>
        </body></html>`,
        { headers: { "Content-Type": "text/html; charset=UTF-8" } }
      );
    }

    function mask(s) {
      if (!s) return "";
      return "•".repeat(Math.max(4, Math.min(12, String(s).length)));
    }

    async function htmlDashboard(env, request) {
      const hostname = new URL(request.url).hostname;
      const base = `https://${hostname}`;
      const pass = await getEffectivePass(env);
      const uuid = await getEffectiveUUID(env);

      // List KV keys (excluding config keys)
      const kvList = await env.SUBS.list({ limit: 200 });
      const keys = (kvList.keys || []).map(k => k.name).filter(n => !n.startsWith("cfg:"));

      return new Response(
        `<!DOCTYPE html><html lang="fa"><head>
          <meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
          <title>Dashboard · Semi-Pro Panel</title>
          <style>${styles}</style>
        </head><body>
          <div class="wrap">
            <div class="topbar">
              <div class="left">
                <h1 class="title">My Semi-Pro Panel</h1>
                <div class="subtitle">پنل مدیریت ساده با KV · تم شب · ریسپانسیو</div>
              </div>
              <div class="right">
                <a class="btn sec" href="/logout">خروج</a>
              </div>
            </div>

            <div class="grid">
              <div class="card">
                <h2>اطلاعات</h2>
                <div class="small">در این بخش اطلاعات پایه و لینک ثابت نمایش داده می‌شود.</div>
                <div class="sep"></div>
                <div class="row">
                  <div class="col">
                    <label>UUID</label>
                    <div class="copyRow">
                      <code id="uuidText">${uuid}</code>
                      <button class="btn sec" onclick="copyText('uuidText')">کپی</button>
                    </div>
                  </div>
                  <div class="col">
                    <label>Panel Password</label>
                    <div class="copyRow">
                      <code id="passText" data-real="${pass}">${mask(pass)}</code>
                      <button class="btn sec" onclick="togglePass()">نمایش/مخفی</button>
                    </div>
                  </div>
                </div>
                <div class="row" style="margin-top:12px">
                  <div class="col">
                    <label>Subscription Base (نمایشی)</label>
                    <div class="copyRow">
                      <code id="baseText">${base}/sub/NAME</code>
                      <button class="btn sec" onclick="copyText('baseText')">کپی</button>
                    </div>
                  </div>
                  <div class="col">
                    <label>Worker Host</label>
                    <div class="pill">${hostname}</div>
                  </div>
                </div>
              </div>

              <div class="card">
                <h2>تنظیمات پنل</h2>
                <div class="small">تغییر رمز پنل و UUID به صورت امن در KV ذخیره می‌شود.</div>
                <div class="sep"></div>
                <form method="POST" action="/config/save">
                  <div class="row">
                    <div class="col">
                      <label>New Panel Password</label>
                      <input name="new_pass" type="text" placeholder="خالی = بدون تغییر"/>
                    </div>
                    <div class="col">
                      <label>New UUID</label>
                      <input name="new_uuid" type="text" placeholder="خالی = بدون تغییر"/>
                    </div>
                  </div>
                  <div class="row" style="margin-top:12px">
                    <div class="col">
                      <button class="btn ok" type="submit">ذخیره تغییرات</button>
                    </div>
                    <div class="col right">
                      <span class="small">نکته: مقادیر پیش‌فرض از ENV می‌آیند و با مقدار KV override می‌شوند.</span>
                    </div>
                  </div>
                </form>
              </div>
            </div>

            <div class="card">
              <h2>مدیریت KV (namespace: SUBS)</h2>
              <div class="small">افزودن/نمایش/حذف key/value. کلیدهای با پیشوند <code>cfg:</code> در لیست نشان داده نمی‌شوند.</div>
              <div class="sep"></div>
              <div class="row">
                <div class="col">
                  <form method="POST" action="/kv/set">
                    <label>Key</label>
                    <input name="key" placeholder="مثلاً my-list"/>
                    <label style="margin-top:8px">Value (متن آزاد)</label>
                    <textarea name="value" placeholder="متن یا URL"></textarea>
                    <div class="row" style="margin-top:8px">
                      <div class="col">
                        <button class="btn" type="submit">ذخیره / بروزرسانی</button>
                      </div>
                    </div>
                  </form>
                </div>
                <div class="col">
                  <form method="GET" action="/kv/get">
                    <label>Get Key</label>
                    <div class="row">
                      <div class="col">
                        <input name="key" placeholder="مثلاً my-list"/>
                      </div>
                      <div class="col">
                        <button class="btn sec" type="submit">نمایش</button>
                      </div>
                    </div>
                  </form>

                  <form method="POST" action="/kv/del" style="margin-top:10px">
                    <label>Delete Key</label>
                    <div class="row">
                      <div class="col">
                        <input name="key" placeholder="کلید برای حذف"/>
                      </div>
                      <div class="col">
                        <button class="btn danger" type="submit">حذف</button>
                      </div>
                    </div>
                  </form>

                  <div style="margin-top:10px">
                    <label>Keys (max 200)</label>
                    <div style="max-height:180px;overflow:auto;border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:8px">
                      ${
                        keys.length
                          ? keys.map(k => `<div class="small">• <code>${k}</code></div>`).join("")
                          : `<div class="small">لیستی برای نمایش وجود ندارد.</div>`
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="footer">Developed for you · Semi-Pro Panel · KV + Auth</div>
          </div>

          <script>
            function copyText(id){
              try{
                const el = document.getElementById(id);
                const v = el ? (el.innerText || el.textContent) : "";
                navigator.clipboard.writeText(v);
                alert("کپی شد: " + v);
              }catch(e){ alert("Copy failed"); }
            }
            function togglePass(){
              const el = document.getElementById("passText");
              const real = el.getAttribute("data-real");
              const isMasked = el.textContent.startsWith("•");
              el.textContent = isMasked ? real : "•".repeat(Math.max(4, Math.min(12, real.length)));
            }
          </script>
        </body></html>`,
        { headers: { "Content-Type": "text/html; charset=UTF-8" } }
      );
    }

    // ---------- Auth state ----------
    const cookieAuth = getCookie(request, "auth") === "1";
    const isLoginPage = (path === "/" || path === "/index.html" || path === "/login");
    const isStatic = false;

    // ---------- Routes ----------
    if (path === "/login" && method === "GET") {
      if (cookieAuth) return redirect("/");
      return htmlLogin();
    }
    if (isLoginPage && method === "GET") {
      if (!cookieAuth) return htmlLogin();
      return htmlDashboard(env, request);
    }

    if (path === "/login" && method === "POST") {
      const form = await request.formData();
      const passInput = (form.get("pass") || "").toString().trim();
      const passReal = await getEffectivePass(env);
      if (passInput && passInput === passReal) {
        return redirect("/", { "Set-Cookie": setCookieHeader("auth", "1", 60 * 60 * 8) });
      } else {
        return new Response("Wrong password. <a href='/login'>Back</a>", { status: 401, headers: { "Content-Type": "text/html; charset=UTF-8" } });
      }
    }

    if (path === "/logout") {
      return redirect("/login", { "Set-Cookie": setCookieHeader("auth", "0", 0) });
    }

    // All routes below require auth
    if (!cookieAuth) return redirect("/login");

    // Save config (pass/uuid) to KV
    if (path === "/config/save" && method === "POST") {
      const form = await request.formData();
      const newPass = (form.get("new_pass") || "").toString().trim();
      const newUUID = (form.get("new_uuid") || "").toString().trim();
      if (newPass) await env.SUBS.put("cfg:pass", newPass);
      if (newUUID) await env.SUBS.put("cfg:uuid", newUUID);
      return redirect("/");
    }

    // KV: set
    if (path === "/kv/set" && method === "POST") {
      const form = await request.formData();
      const key = (form.get("key") || "").toString().trim();
      const value = (form.get("value") || "").toString();
      if (!key) return new Response("Key is required", { status: 400 });
      await env.SUBS.put(key, value);
      return redirect("/");
    }

    // KV: del
    if (path === "/kv/del" && method === "POST") {
      const form = await request.formData();
      const key = (form.get("key") || "").toString().trim();
      if (!key) return new Response("Key is required", { status: 400 });
      await env.SUBS.delete(key);
      return redirect("/");
    }

    // KV: get
    if (path === "/kv/get" && method === "GET") {
      const key = (url.searchParams.get("key") || "").trim();
      if (!key) return new Response("Provide a key via ?key=NAME", { status: 400 });
      const val = await env.SUBS.get(key);
      return new Response(val || "", { headers: { "Content-Type": "text/plain; charset=UTF-8" } });
    }

    // Default: dashboard
    return htmlDashboard(env, request);
  }
};