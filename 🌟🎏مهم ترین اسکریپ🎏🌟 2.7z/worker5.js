const DEFAULT_RENAME_TAG = 'ViP RGB馃殌';

const INITIAL_CONFIG_LIMITS = [12, 24, 36];
const DYNAMIC_CONFIG_LIMITS = [10, 20, 30, 50, 'all'];

const cache = new Map();
const CACHE_TTL = 20;

async function getCachedData(key, fetcher) {
    const cached = cache.get(key);
    if (cached && (Date.now() - cached.timestamp < CACHE_TTL * 1000)) {
        return cached.data;
    }
    const data = await fetcher();
    cache.set(key, { data, timestamp: Date.now() });
    return data;
}

function limitConfigs(configs, limit) {
    if (limit === 'all') return configs;
    const numLimit = parseInt(limit, 10);
    if (isNaN(numLimit) || numLimit <= 0) return configs;
    return configs.slice(0, numLimit);
}

function renameConfigs(configs, newName) {
    if (!newName) return configs;
    return configs.map(config => {
        const hashIndex = config.indexOf('#');
        if (hashIndex !== -1) {
            return config.substring(0, hashIndex) + '#' + newName;
        }
        return config + '#' + newName;
    });
}

async function fetchConfigsFromRepo(url) {
    let allConfigs = [];
    try {
        const response = await fetch(url);
        if (response.ok) {
            const text = await response.text();
            allConfigs = text.split('\n').filter(Boolean);
        }
    } catch (e) {
        console.error(`Failed to fetch ${url}:`, e);
    }
    return allConfigs;
}

function getPanelPage() {
    const initialLimitButtons = INITIAL_CONFIG_LIMITS.map(limit => `
        <div class="card limit-card initial-limit" data-limit="${limit}">
            <div class="card-title">${limit}</div>
        </div>
    `).join('');

    const dynamicLimitButtons = DYNAMIC_CONFIG_LIMITS.map(limit => `
        <div class="card limit-card dynamic-limit" data-limit="${limit}">
            <div class="card-title">${limit === 'all' ? '全部' : limit}</div>
        </div>
    `).join('');

    return `
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PANEL RGB</title>
<style>
/* --- CSS پنل --- */
body { font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin:0; padding:0; min-height:100vh; display:flex; flex-direction:column; align-items:center; background:linear-gradient(270deg,#ff0000,#ff7f00,#ffff00,#00ff00,#0000ff,#4b0082,#9400d3); background-size:1400% 1400%; animation:background-animation 30s ease infinite; color:#f0f0f0; }
@keyframes background-animation { 0%{background-position:0% 50%;} 50%{background-position:100% 50%;} 100%{background-position:0% 50%;} }
.panel-title { font-size:2.5rem; font-weight:bold; text-align:center; margin:20px 0; }
.cards-container { display:flex; flex-wrap:wrap; justify-content:center; gap:15px; margin:20px 0; }
.card { background: rgba(255,255,255,0.1); backdrop-filter: blur(8px); border:1px solid rgba(255,255,255,0.18); border-radius:15px; padding:20px; width:150px; text-align:center; cursor:pointer; transition: all 0.3s ease; }
.card.selected { background: rgba(0,255,204,0.3); border:2px solid #00ffcc; }
.name-input { width:100%; max-width:400px; padding:10px; background: rgba(255,255,255,0.1); border:1px solid rgba(255,255,255,0.18); border-radius:10px; text-align:center; margin-bottom:15px; color:#f0f0f0; }
.btn-create { width:100%; max-width:400px; padding:12px; background: rgba(0,255,204,0.2); border:1px solid rgba(255,255,255,0.18); border-radius:10px; font-weight:bold; cursor:pointer; margin-bottom:20px; }
.btn-create:disabled { background: rgba(100,100,100,0.2); cursor:not-allowed; }
.result-container { display:none; padding:20px; background: rgba(0,0,0,0.3); border-radius:10px; max-width:800px; margin-bottom:20px; word-break: break-all; }
</style>

<!-- === منابع خارجی === -->
<!-- 1. کتابخانه QRCode.js برای تولید QR کد -->
<script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
<!-- 2. فایل کانفیگ V2Ray از گیت‌هاب (سورس اصلی) -->
<!-- این URL در کد Cloudflare Worker استفاده شده و می‌توانید آن را جایگزین کنید -->
<!-- const SINGLE_REPO_URL = 'https://raw.githubusercontent.com/Rayan-Config/C-Sub/refs/heads/main/configs/proxy.txt'; -->

</head>
<body>
<h1 class="panel-title">PANEL RGB</h1>

<div class="cards-container" id="initialLimitsContainer">
${initialLimitButtons}
<div class="card limit-card more-button" id="moreLimitsBtn"><div class="card-title">更多...</div></div>
</div>

<div class="cards-container" id="dynamicLimitsContainer" style="display:none;">
${dynamicLimitButtons}
</div>

<input type="text" id="configNameInput" class="name-input" placeholder="نام دلخواه: ${DEFAULT_RENAME_TAG}">
<button id="createConfigBtn" class="btn-create" disabled>生成配置</button>

<div class="result-container" id="resultSection">
<div id="subscribeLink"></div>
<div id="qrCodeContainer"></div>
<button id="copyBtn" class="btn-create" disabled>複製鏈接</button>
</div>

<script>
document.addEventListener('DOMContentLoaded',()=>{
    let selectedLimit = null;
    const initialLimitsContainer = document.getElementById('initialLimitsContainer');
    const dynamicLimitsContainer = document.getElementById('dynamicLimitsContainer');
    const moreLimitsBtn = document.getElementById('moreLimitsBtn');
    const createConfigBtn = document.getElementById('createConfigBtn');
    const configNameInput = document.getElementById('configNameInput');
    const resultSection = document.getElementById('resultSection');
    const subscribeLink = document.getElementById('subscribeLink');
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    const copyBtn = document.getElementById('copyBtn');

    function handleLimitSelection(card){
        document.querySelectorAll('.limit-card').forEach(c=>c.classList.remove('selected'));
        card.classList.add('selected');
        selectedLimit = card.getAttribute('data-limit');
        createConfigBtn.disabled = false;
        resultSection.style.display = 'none';
    }

    initialLimitsContainer.addEventListener('click',e=>{
        const card = e.target.closest('.limit-card');
        if(!card) return;
        if(card.id==='moreLimitsBtn'){
            initialLimitsContainer.style.display='none';
            dynamicLimitsContainer.style.display='flex';
            document.querySelectorAll('.limit-card').forEach(c=>c.classList.remove('selected'));
            selectedLimit=null;
            createConfigBtn.disabled=true;
        } else {
            handleLimitSelection(card);
        }
    });

    dynamicLimitsContainer.addEventListener('click',e=>{
        const card = e.target.closest('.limit-card');
        if(!card) return;
        handleLimitSelection(card);
    });

    createConfigBtn.addEventListener('click',()=>{
        if(!selectedLimit) return;
        const baseUrl = window.location.origin;
        const customName = configNameInput.value.trim() || '${DEFAULT_RENAME_TAG}';
        const params = new URLSearchParams();
        if(selectedLimit!=='all') params.set('limit',selectedLimit);
        params.set('name',customName);
        const fullUrl = baseUrl + '/subscribe?' + params.toString();
        subscribeLink.textContent = fullUrl;
        qrCodeContainer.innerHTML='';
        new QRCode(qrCodeContainer,{text:fullUrl,width:150,height:150,colorDark:"#f0f0f0",colorLight:"rgba(0,0,0,0)",correctLevel:QRCode.CorrectLevel.H});
        resultSection.style.display='block';
        copyBtn.disabled=false;
    });

    copyBtn.addEventListener('click',()=>{
        navigator.clipboard.writeText(subscribeLink.textContent).then(()=>{alert('لینک کپی شد!');}).catch(()=>{alert('کپی موفق نبود');});
    });
});
</script>
</body>
</html>
`;
}

export default {
    async fetch(request) {
        const url = new URL(request.url);
        const path = url.pathname;

        /* === منبع اصلی کانفیگ V2Ray === */
        // می‌توانید این URL را با منبع خود جایگزین کنید
        const SINGLE_REPO_URL = 'https://raw.githubusercontent.com/Rayan-Config/C-Sub/refs/heads/main/configs/proxy.txt';

        if(path==='/subscribe'){
            const cacheKey=url.toString();
            const cachedResponse=await getCachedData(cacheKey,async()=>{
                let allConfigs=await fetchConfigsFromRepo(SINGLE_REPO_URL);
                const customName=url.searchParams.get('name')||DEFAULT_RENAME_TAG;
                allConfigs=renameConfigs(allConfigs,customName);
                const limit=url.searchParams.get('limit')||'all';
                return limitConfigs(allConfigs,limit);
            });
            return new Response(cachedResponse.join('\n'),{headers:{'Content-Type':'text/plain; charset=utf-8'}});
        }

        return new Response(getPanelPage(),{headers:{'Content-Type':'text/html; charset=utf-8'}});
    }
};