// worker.js

const PASSWORD = "12345"; // اینجا رمز ورود خودتو بذار

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // اگر هنوز لاگین نشده
    const cookie = request.headers.get("Cookie") || "";
    const loggedIn = cookie.includes("session=ok");

    // مسیر لاگین
    if (url.pathname === "/login") {
      if (request.method === "POST") {
        const formData = await request.formData();
        const pass = formData.get("password");
        if (pass === PASSWORD) {
          return new Response(renderPanel(), {
            headers: {
              "Content-Type": "text/html;charset=UTF-8",
              "Set-Cookie": "session=ok; path=/; HttpOnly; Secure",
            },
          });
        } else {
          return new Response(renderLogin("رمز اشتباه است ❌"), {
            headers: { "Content-Type": "text/html;charset=UTF-8" },
          });
        }
      }
      return new Response(renderLogin(), {
        headers: { "Content-Type": "text/html;charset=UTF-8" },
      });
    }

    // اگر لاگین نشده → هدایت به لاگین
    if (!loggedIn) {
      return Response.redirect(url.origin + "/login", 302);
    }

    // اگر لاگین شده → نمایش پنل اصلی
    if (url.pathname === "/" || url.pathname === "/panel") {
      return new Response(renderPanel(), {
        headers: { "Content-Type": "text/html;charset=UTF-8" },
      });
    }

    // خروجی‌های Sub (raw / txt / json / yaml)
    if (url.pathname === "/raw") {
      return new Response("vmess://example-raw", {
        headers: { "Content-Type": "text/plain;charset=UTF-8" },
      });
    }
    if (url.pathname === "/txt") {
      return new Response("vmess://example-txt", {
        headers: { "Content-Type": "text/plain;charset=UTF-8" },
      });
    }
    if (url.pathname === "/json") {
      return new Response(JSON.stringify({ type: "vmess", data: "example" }), {
        headers: { "Content-Type": "application/json;charset=UTF-8" },
      });
    }
    if (url.pathname === "/yaml") {
      return new Response("proxies:\n  - { name: test, type: vmess }", {
        headers: { "Content-Type": "text/yaml;charset=UTF-8" },
      });
    }

    // دیفالت → برگرده به پنل
    return Response.redirect(url.origin + "/panel", 302);
  },
};

// صفحه لاگین شیک
function renderLogin(msg = "") {
  return `
  <html dir="rtl" lang="fa">
  <head>
    <meta charset="UTF-8" />
    <title>ورود به پنل</title>
    <style>
      body { display:flex;align-items:center;justify-content:center;height:100vh;background:#0f172a;color:#fff;font-family:sans-serif; }
      .box { background:#1e293b;padding:30px;border-radius:15px;text-align:center;box-shadow:0 0 20px rgba(0,0,0,0.6); }
      input { padding:10px;border:none;border-radius:8px;margin:10px;width:200px;text-align:center; }
      button { padding:10px 20px;border:none;border-radius:8px;background:#3b82f6;color:white;cursor:pointer; }
      .msg { color:#f87171;margin-top:10px; }
    </style>
  </head>
  <body>
    <form method="POST" class="box">
      <h2>🔑 رمز ورود</h2>
      <input type="password" name="password" placeholder="رمز عبور" required />
      <br/>
      <button type="submit">ورود</button>
      <div class="msg">${msg}</div>
    </form>
  </body>
  </html>`;
}

// پنل اصلی (شیک و بدون تغییر فرمتی که داشتی)
function renderPanel() {
  return `
  <html dir="rtl" lang="fa">
  <head>
    <meta charset="UTF-8" />
    <title>⚡ My Semi-Pro Panel ⚡</title>
    <style>
      body { background:#0f172a;color:#fff;font-family:sans-serif;text-align:center;padding:30px; }
      h1 { color:#3b82f6; }
      a { display:block;margin:10px auto;padding:10px 20px;background:#1e293b;color:#fff;text-decoration:none;border-radius:10px;width:250px; }
      a:hover { background:#3b82f6; }
    </style>
  </head>
  <body>
    <h1>⚡ My Semi-Pro Panel ⚡</h1>
    <p>📡 مدیریت سورس‌ها و ساخت Sub</p>
    <hr/>
    <a href="/raw">📄 Sub (Raw)</a>
    <a href="/txt">📄 Sub (TXT)</a>
    <a href="/json">📄 Sub (JSON)</a>
    <a href="/yaml">📄 Sub (YAML)</a>
  </body>
  </html>`;
}