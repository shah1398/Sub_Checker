// ======= Semi-Pro Proxy Panel (Worker + KV) =======
// KV binding: env.SUBS (Name=SUBS, Namespace=subs)
// Vars: PANEL_PASS, UUID
// Routes:
//  - GET  /login, POST /login
//  - GET  /panel  (protected)
//  - GET  /sub       -> subscription output (links)
//  - GET  /yaml      -> Clash Meta YAML output
//  - GET  /api/list  -> list all links (JSON)
//  - POST /api/add   -> add links (JSON {lines: "..."})
//  - POST /api/del   -> delete by indices (JSON {indices: [..]})
//  - POST /api/save  -> save PANEL_PASS / UUID into KV (JSON)
//  - POST /api/clear -> clear all list (confirm)
// Auth via cookie "sess=1"

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // ---- helpers ----
    const getKV = (k) => env.SUBS.get(k);
    const putKV = (k, v) => env.SUBS.put(k, v);
    const delKV = (k) => env.SUBS.delete(k);

    const getCookie = (req, name) => {
      const c = req.headers.get("Cookie") || "";
      const m = c.match(new RegExp("(^|; )" + name + "=([^;]+)"));
      return m ? m[2] : null;
    };
    const setCookieHeader = (name, val, maxAge = 3600) =>
      `${name}=${val}; Path=/; HttpOnly; Max-Age=${maxAge}; SameSite=Lax`;

    // ---- auth ----
    const KV_PASS = (await getKV("cfg:PANEL_PASS")) || env.PANEL_PASS || "admin";
    const KV_UUID = (await getKV("cfg:UUID")) || env.UUID || "00000000-0000-0000-0000-000000000000";
    const isAuth = getCookie(request, "sess") === "1";

    // ---- serve static pages ----
    if (path === "/login" && method === "GET") {
      return htmlLogin();
    }
    if (path === "/login" && method === "POST") {
      const form = await request.formData();
      const pass = (form.get("password") || "").trim();
      if (pass && pass === KV_PASS) {
        return new Response(null, {
          status: 302,
          headers: {
            "Location": "/panel",
            "Set-Cookie": setCookieHeader("sess", "1", 2 * 3600)
          }
        });
      } else {
        return new Response(await (await htmlLogin()).text().then(t=>t.replace("</form>","<div style='color:#c00;margin-top:8px'>Wrong password</div></form>")), {
          headers: {"Content-Type":"text/html; charset=UTF-8"}
        });
      }
    }

    if (path === "/" && method === "GET") {
      return new Response(null, { status: 302, headers: { "Location": "/panel" } });
    }

    if (path === "/panel") {
      if (!isAuth) return new Response(null, { status: 302, headers: { "Location": "/login" } });
      return htmlPanel(url, KV_UUID);
    }

    // ---- APIs (protected) ----
    if (path.startsWith("/api/")) {
      if (!isAuth) return json({ ok: false, error: "unauthorized" }, 401);

      if (path === "/api/list" && method === "GET") {
        const list = await loadList(env);
        return json({ ok: true, count: list.length, items: list });
      }

      if (path === "/api/add" && method === "POST") {
        const data = await readJSON(request);
        const linesRaw = (data.lines || "").trim();
        if (!linesRaw) return json({ ok: false, error: "no lines" }, 400);
        const addRes = await addLines(env, linesRaw);
        return json({ ok: true, ...addRes });
      }

      if (path === "/api/del" && method === "POST") {
        const data = await readJSON(request);
        const indices = data.indices;
        if (!Array.isArray(indices)) return json({ ok: false, error: "indices required" }, 400);
        const delRes = await deleteByIndices(env, indices);
        return json({ ok: true, ...delRes });
      }

      if (path === "/api/save" && method === "POST") {
        const data = await readJSON(request);
        const out = {};
        if (data.password && data.password.trim()) {
          await putKV("cfg:PANEL_PASS", data.password.trim());
          out.password = "updated";
        }
        if (data.uuid && data.uuid.trim()) {
          await putKV("cfg:UUID", data.uuid.trim());
          out.uuid = "updated";
        }
        return json({ ok: true, ...out });
      }

      if (path === "/api/clear" && method === "POST") {
        const data = await readJSON(request);
        if (data.confirm !== "YES") return json({ ok: false, error: "confirm with YES" }, 400);
        await putKV("subs:list", "");
        return json({ ok: true, cleared: true });
      }

      return json({ ok: false, error: "unknown api" }, 404);
    }

    // ---- Outputs ----
    if (path === "/sub" && method === "GET") {
      // optional ?n=N for limiting random sample
      const list = await loadList(env);
      const nParam = url.searchParams.get("n");
      let out = list.slice();
      if (nParam && /^\d+$/.test(nParam)) {
        const n = Math.min(parseInt(nParam, 10), out.length);
        out = shuffle(out).slice(0, n);
      }
      return new Response(out.join("\n"), { headers: { "Content-Type": "text/plain; charset=UTF-8" } });
    }

    if (path === "/yaml" && method === "GET") {
      const list = await loadList(env);
      const yamlText = buildClashYaml(list);
      return new Response(yamlText, { headers: { "Content-Type": "text/yaml; charset=UTF-8" } });
    }

    // fallback
    return new Response("Not Found", { status: 404 });
  }
};

// --------- KV list helpers ---------
async function loadList(env) {
  const txt = (await env.SUBS.get("subs:list")) || "";
  const lines = txt.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  // dedupe
  const seen = new Set();
  const out = [];
  for (const l of lines) {
    const norm = l.toLowerCase();
    if (!seen.has(norm)) {
      seen.add(norm);
      out.push(l);
    }
  }
  return out;
}
async function saveList(env, arr) {
  const txt = arr.join("\n");
  await env.SUBS.put("subs:list", txt);
}
async function addLines(env, raw) {
  const incoming = raw.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  let list = await loadList(env);
  const before = list.length;
  const seen = new Set(list.map(l=>l.toLowerCase()));
  for (const x of incoming) {
    if (!seen.has(x.toLowerCase())) {
      list.push(x);
      seen.add(x.toLowerCase());
    }
  }
  await saveList(env, list);
  return { added: list.length - before, total: list.length };
}
async function deleteByIndices(env, indices) {
  let list = await loadList(env);
  const before = list.length;
  // remove by sorted desc indices
  const sorted = [...indices].filter(i=>Number.isInteger(i)).sort((a,b)=>b-a);
  for (const idx of sorted) {
    if (idx >= 0 && idx < list.length) list.splice(idx, 1);
  }
  await saveList(env, list);
  return { deleted: before - list.length, total: list.length };
}

// --------- Utils ---------
function json(obj, status=200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json; charset=UTF-8" } });
}
async function readJSON(req) {
  try {
    return await req.json();
  } catch {
    return {};
  }
}
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// --------- YAML Builder (Clash Meta) ---------
// Supports: vless:// vmess:// trojan:// ss://
function buildClashYaml(lines) {
  const proxies = [];
  const names = new Set();
  let counter = 1;

  for (const raw of lines) {
    try {
      if (raw.startsWith("vless://")) {
        const p = parseUrl(raw);
        const q = p.qs;
        const name = uniqueName(names, displayNameFrom(raw, "vless", counter++));
        const obj = {
          name, type: "vless",
          server: p.host, port: p.port || 443,
          uuid: p.user || "",
          udp: true,
          encryption: "none"
        };
        const security = q.security?.[0] || "";
        if (security.toLowerCase() === "tls") {
          obj.tls = true;
          if (q.sni?.[0]) obj.servername = q.sni[0];
        }
        const type = q.type?.[0] || "tcp";
        if (type === "ws") {
          obj.network = "ws";
          obj["ws-opts"] = {};
          if (q.path?.[0]) obj["ws-opts"].path = q.path[0];
          if (q.host?.[0]) obj["ws-opts"].headers = { Host: q.host[0] };
        } else obj.network = type;
        proxies.push(obj);
      } else if (raw.startsWith("vmess://")) {
        const b64 = raw.slice(8);
        const decoded = atobSafe(b64);
        const info = safeJson(decoded) || {};
        const name = uniqueName(names, displayNameFrom(raw, "vmess", counter++));
        const obj = {
          name, type: "vmess",
          server: info.add || "",
          port: toInt(info.port, 443),
          uuid: info.id || "",
          alterId: toInt(info.aid, 0),
          cipher: "auto",
          udp: true
        };
        if ((info.tls || "").toLowerCase() === "tls") {
          obj.tls = true;
          if (info.sni) obj.servername = info.sni;
        }
        if ((info.net || "tcp") === "ws") {
          obj.network = "ws";
          obj["ws-opts"] = { path: info.path || "/" };
          if (info.host) obj["ws-opts"].headers = { Host: info.host };
        } else obj.network = info.net || "tcp";
        proxies.push(obj);
      } else if (raw.startsWith("trojan://")) {
        const p = parseUrl(raw);
        const name = uniqueName(names, displayNameFrom(raw, "trojan", counter++));
        const obj = {
          name, type: "trojan",
          server: p.host, port: p.port || 443,
          password: p.user || "",
          udp: true
        };
        if (p.qs.sni?.[0]) obj.sni = p.qs.sni[0];
        proxies.push(obj);
      } else if (raw.startsWith("ss://")) {
        // try modern form: ss://base64(ciph:pass)@host:port or ss://cipher:pass@host:port
        const name = uniqueName(names, displayNameFrom(raw, "ss", counter++));
        let cipher="", password="", server="", port=0;
        const m1 = raw.match(/^ss:\/\/([^:]+):([^@]+)@([^:]+):(\d+)/i);
        if (m1) {
          cipher=m1[1]; password=m1[2]; server=m1[3]; port=parseInt(m1[4]);
        } else {
          // ss://base64@host:port format
          const m2 = raw.match(/^ss:\/\/([^@]+)@([^:]+):(\d+)/i);
          if (m2) {
            const cred = atobSafe(m2[1] || "");
            const parts = cred.split(":");
            if (parts.length >= 2) { cipher=parts[0]; password=parts.slice(1).join(":"); }
            server = m2[2]; port = parseInt(m2[3]);
          }
        }
        if (cipher && password && server && port) {
          proxies.push({
            name, type: "ss",
            server, port, cipher, password
          });
        }
      }
    } catch {}
  }

  const proxyNames = proxies.map(p=>p.name);
  const yml = {
    "mixed-port": 7890,
    "allow-lan": false,
    "mode": "rule",
    "ipv6": false,
    "log-level": "info",
    "external-controller": "0.0.0.0:9090",
    "dns": {
      "enable": true,
      "listen": "0.0.0.0:53",
      "ipv6": false,
      "default-nameserver": ["223.5.5.5","114.114.114.114"],
      "nameserver": ["223.5.5.5","114.114.114.114","119.29.29.29","180.76.76.76"],
      "enhanced-mode": "fake-ip",
      "fake-ip-range": "198.18.0.1/16",
      "fake-ip-filter": [
        "*.lan","*.localdomain","*.example","*.invalid","*.localhost","*.test","*.local","*.home.arpa",
        "router.asus.com","localhost.sec.qq.com","localhost.ptlogin2.qq.com","+.msftconnecttest.com"
      ]
    },
    "tun": {
      "enable": true, "stack": "system", "auto-route": true, "auto-detect-interface": true,
      "dns-hijack": ["114.114.114.114","180.76.76.76","119.29.29.29","223.5.5.5","8.8.8.8","8.8.4.4","1.1.1.1","1.0.0.1"]
    },
    "proxies": proxies,
    "proxy-groups": [
      { "name": "Proxy-Select", "type": "select", "proxies": ["Auto-Select","DIRECT", ...proxyNames] },
      { "name": "Auto-Select", "type": "url-test", "url": "http://www.gstatic.com/generate_204", "proxies": proxyNames, "interval": 300, "tolerance": 5000 },
      { "name": "Direct", "type": "select", "proxies": ["DIRECT","Proxy-Select","Auto-Select"] },
      { "name": "Reject", "type": "select", "proxies": ["REJECT","DIRECT"] },
      { "name": "Final",  "type": "select", "proxies": ["Proxy-Select","Direct","Auto-Select", ...proxyNames] }
    ],
    "rules": [
      "DOMAIN-SUFFIX,localhost,Direct",
      "IP-CIDR,192.168.0.0/16,Direct,no-resolve",
      "MATCH,Final"
    ]
  };
  return dumpYAML(yml);
}

// --- tiny YAML dumper (enough for our schema) ---
function dumpYAML(obj, indent=0) {
  const sp = "  ".repeat(indent);
  if (obj === null) return "null";
  if (typeof obj === "string") return (obj.match(/[:#\-\?\{\}\[\],&\*!\|>'"%@`]/) ? JSON.stringify(obj) : obj);
  if (typeof obj === "number" || typeof obj === "boolean") return String(obj);
  if (Array.isArray(obj)) {
    if (obj.length === 0) return "[]";
    return obj.map(v => sp + "- " + dumpYAML(v, indent+1).replace(/^\s+/, "")).join("\n");
  }
  if (typeof obj === "object") {
    const keys = Object.keys(obj);
    if (keys.length === 0) return "{}";
    return keys.map(k => {
      const v = obj[k];
      const val = dumpYAML(v, indent+1);
      if (typeof v === "object" && v !== null && !Array.isArray(v)) {
        return sp + k + ":\n" + "  ".repeat(indent+1) + val.replace(/\n/g, "\n" + "  ".repeat(indent+1));
      } else {
        return sp + k + ": " + val;
      }
    }).join("\n");
  }
  return String(obj);
}

// ---- parsers ----
function atobSafe(s) {
  try { return atob(s.replace(/-/g,'+').replace(/_/g,'/')); } catch { return ""; }
}
function toInt(v, def=0) {
  const n = parseInt(v,10);
  return isNaN(n) ? def : n;
}
function safeJson(s) {
  try { return JSON.parse(s); } catch { return null; }
}
function uniqueName(set, base) {
  let name = base;
  let i = 1;
  while (set.has(name)) { name = `${base}-${i++}`; }
  set.add(name);
  return name;
}
function displayNameFrom(link, proto, idx) {
  // prefer fragment (#name)
  const h = link.split("#")[1];
  if (h) return cleanTitle(decodeURIComponent(h));
  return `${proto.toUpperCase()}-${idx}`;
}
function cleanTitle(s) {
  return s.replace(/[^\w\s\-.@]/g, "").trim() || "Proxy";
}
function parseUrl(link) {
  // use basic parser
  const u = new URL(link);
  const qs = {};
  u.searchParams.forEach((v,k)=>{
    if (!qs[k]) qs[k]=[];
    qs[k].push(v);
  });
  return {
    scheme: u.protocol.replace(":",""),
    user: u.username,
    pass: u.password,
    host: u.hostname,
    port: u.port ? parseInt(u.port) : null,
    path: u.pathname || "/",
    hash: u.hash ? u.hash.slice(1) : "",
    qs
  };
}

// --------- HTML ---------
function htmlLogin() {
  const html = `<!DOCTYPE html><html lang="fa"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Login</title>
<style>
  body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f172a;font-family:Inter,system-ui,Arial}
  .card{width:360px;background:#0b1220;border:1px solid #23324a;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,.4);padding:22px;color:#c9d5e1}
  h1{margin:0 0 14px;font-size:18px;color:#fff}
  label{display:block;margin:8px 0 6px}
  input{width:100%;padding:11px;border-radius:8px;border:1px solid #2e405f;background:#0a1220;color:#e6efff}
  button{margin-top:12px;padding:11px;width:100%;border:0;border-radius:8px;background:#3b82f6;color:#fff;cursor:pointer}
  .hint{font-size:12px;color:#8ca3bf;margin-top:8px}
</style></head><body>
<form class="card" method="POST" action="/login">
  <h1>Panel Login</h1>
  <label>Password</label>
  <input name="password" type="password" required/>
  <button type="submit">Sign In</button>
  <div class="hint">Env/KV: PANEL_PASS</div>
</form>
</body></html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=UTF-8" } });
}

function htmlPanel(url, uuidVal) {
  const host = url.hostname;
  const baseSub = `${url.origin}/sub`;
  const baseYaml = `${url.origin}/yaml`;
  const html = `<!DOCTYPE html><html lang="fa"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>My Semi-Pro Panel</title>
<style>
  :root{--bg:#0f172a;--panel:#0b1220;--muted:#879bb6;--fg:#cfe2ff;--pri:#3b82f6;--ok:#22c55e;--bad:#ef4444;--b:#22324a}
  body{margin:0;background:var(--bg);font-family:Inter,system-ui,Arial;color:var(--fg)}
  .wrap{max-width:980px;margin:30px auto;padding:0 16px}
  .card{background:var(--panel);border:1px solid var(--b);border-radius:12px;padding:18px;box-shadow:0 10px 40px rgba(0,0,0,.35)}
  h1{margin:0 0 12px;font-size:22px}
  .tabs{display:flex;gap:8px;margin-bottom:10px}
  .tab{padding:8px 12px;border:1px solid var(--b);background:#0a1322;border-radius:8px;cursor:pointer;color:#b9cbe4}
  .tab.active{background:#16223a;color:#fff;border-color:#2a3e5f}
  .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  label{display:block;margin-top:8px;font-weight:600}
  input,textarea{width:100%;padding:10px;background:#0a1220;border:1px solid var(--b);border-radius:8px;color:#e8f1ff}
  textarea{min-height:110px}
  button{padding:10px 12px;border:0;border-radius:8px;background:var(--pri);color:#fff;cursor:pointer}
  .muted{color:var(--muted);font-size:13px}
  .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .list{max-height:300px;overflow:auto;border:1px dashed var(--b);padding:8px;border-radius:8px;background:#0a1220}
  .item{display:flex;gap:6px;align-items:center;padding:6px;border-bottom:1px solid #152136;font-size:12px}
  .item:last-child{border-bottom:0}
  .badge{background:#1a2844;padding:2px 6px;border-radius:6px;color:#a7c2f0}
  .small{font-size:12px}
</style>
</head><body>
<div class="wrap">
  <div class="card">
    <h1>My Semi-Pro Panel</h1>
    <div class="muted">Worker Host: <b>${host}</b> — Subscription: <code>${baseSub}</code> — YAML: <code>${baseYaml}</code></div>
  </div>

  <div class="card" style="margin-top:12px">
    <div class="tabs">
      <div class="tab active" data-tab="sources">Sources</div>
      <div class="tab" data-tab="outputs">Outputs</div>
      <div class="tab" data-tab="settings">Settings</div>
    </div>

    <div id="tab-sources">
      <div class="grid">
        <div>
          <label>Add Links (single or batch)</label>
          <textarea id="txtLines" placeholder="Paste links here (vless://, vmess://, trojan://, ss://)"></textarea>
          <div class="row">
            <button id="btnAdd">Add</button>
            <button id="btnClear" style="background:#ef4444">Clear All</button>
          </div>
          <div class="muted small">Duplicates ignored automatically.</div>
        </div>
        <div>
          <label>Current Items</label>
          <div class="list" id="list"></div>
          <div class="row">
            <input id="delIndices" placeholder="Indices to delete (e.g. 0,2,5)"/>
            <button id="btnDel" style="background:#d97706">Delete Selected</button>
          </div>
          <div class="muted small">Index starts at 0.</div>
        </div>
      </div>
    </div>

    <div id="tab-outputs" style="display:none">
      <label>Subscription</label>
      <div class="row">
        <input id="subUrl" value="${baseSub}" readonly/>
        <button onclick="copy('#subUrl')">Copy</button>
      </div>
      <label>Clash Meta YAML</label>
      <div class="row">
        <input id="yamlUrl" value="${baseYaml}" readonly/>
        <button onclick="copy('#yamlUrl')">Copy</button>
      </div>
      <div class="muted small">You can use <code>?n=100</code> on <b>/sub</b> to limit random sample.</div>
    </div>

    <div id="tab-settings" style="display:none">
      <div class="grid">
        <div>
          <label>New Panel Password</label>
          <input id="newPass" placeholder="leave empty to keep"/>
          <label>New UUID</label>
          <input id="newUUID" placeholder="leave empty to keep" value="${uuidVal}"/>
          <div class="row" style="margin-top:8px">
            <button id="btnSaveCfg">Save</button>
          </div>
          <div class="muted small">Saved securely in KV (cfg:PANEL_PASS, cfg:UUID)</div>
        </div>
        <div>
          <label>Notes</label>
          <div class="muted small">All links are stored in KV key: <code>subs:list</code>. You can export / import easily.</div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
const $ = sel => document.querySelector(sel);

function showTab(name){
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('#tab-sources,#tab-outputs,#tab-settings').forEach(el=>el.style.display='none');
  document.querySelector('.tab[data-tab="'+name+'"]').classList.add('active');
  $('#tab-'+name).style.display='block';
}
document.querySelectorAll('.tab').forEach(t=>{
  t.addEventListener('click',()=>showTab(t.dataset.tab));
});

async function refreshList(){
  const r = await fetch('/api/list');
  const j = await r.json();
  const box = $('#list');
  box.innerHTML = '';
  if(!j.ok || !j.items || !j.items.length){
    box.innerHTML = '<div class="muted small">No items</div>';
    return;
  }
  j.items.forEach((it, idx)=>{
    const div = document.createElement('div');
    div.className='item';
    div.innerHTML = '<span class="badge">#'+idx+'</span><span>'+escapeHtml(it)+'</span>';
    box.appendChild(div);
  });
}
function escapeHtml(s){ return s.replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }

$('#btnAdd').addEventListener('click', async ()=>{
  const lines = $('#txtLines').value.trim();
  if(!lines){ alert('Paste links first'); return; }
  const r = await fetch('/api/add', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ lines })});
  const j = await r.json();
  if(j.ok){ alert('Added: '+j.added+' — total: '+j.total); $('#txtLines').value=''; refreshList(); }
  else{ alert('Error: '+(j.error||'unknown')); }
});

$('#btnDel').addEventListener('click', async ()=>{
  const s = $('#delIndices').value.trim();
  if(!s){ alert('Enter indices'); return; }
  const inds = s.split(',').map(x=>parseInt(x,10)).filter(x=>!isNaN(x));
  const r = await fetch('/api/del', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ indices: inds })});
  const j = await r.json();
  if(j.ok){ alert('Deleted: '+j.deleted+' — total: '+j.total); $('#delIndices').value=''; refreshList(); }
  else{ alert('Error: '+(j.error||'unknown')); }
});

$('#btnSaveCfg').addEventListener('click', async ()=>{
  const password = $('#newPass').value;
  const uuid = $('#newUUID').value;
  const r = await fetch('/api/save', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ password, uuid })});
  const j = await r.json();
  if(j.ok){ alert('Saved. '+(j.password?'Password updated. ':'')+(j.uuid?'UUID updated.':'')); }
  else{ alert('Error: '+(j.error||'unknown')); }
});

$('#btnClear').addEventListener('click', async ()=>{
  if(!confirm('Clear ALL items in KV?')) return;
  const r = await fetch('/api/clear', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ confirm: 'YES' })});
  const j = await r.json();
  if(j.ok){ alert('Cleared'); refreshList(); }
  else{ alert('Error: '+(j.error||'unknown')); }
});

function copy(sel){
  const el = document.querySelector(sel);
  el.select(); el.setSelectionRange(0,99999);
  document.execCommand('copy');
}

refreshList();
</script>
</body></html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=UTF-8" } });
}